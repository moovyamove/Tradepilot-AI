"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useCallback, useEffect, useState, type ReactNode } from "react";
import { Badge, Button, money } from "./ui";

const NAV = [
  { href: "/dashboard", label: "Dashboard", icon: "▦" },
  { href: "/markets", label: "Markets", icon: "◈" },
  { href: "/opportunities", label: "Opportunities", icon: "✦" },
  { href: "/positions", label: "Positions", icon: "◉" },
  { href: "/history", label: "Trade History", icon: "≡" },
  { href: "/strategies", label: "Strategies", icon: "⚙" },
  { href: "/backtesting", label: "Backtesting", icon: "◴" },
  { href: "/risk", label: "Risk Management", icon: "⛨" },
  { href: "/connections", label: "API Connections", icon: "⇄" },
  { href: "/settings", label: "Settings", icon: "✧" },
];

type Summary = {
  account: { mode: string; autoTrading: boolean; killSwitch: boolean; killReason: string | null };
  metrics: { equity: number; dayPnl: number; totalPnl: number; drawdownPct: number };
};

export default function Shell({ children, userName }: { children: ReactNode; userName: string }) {
  const pathname = usePathname();
  const router = useRouter();
  const [s, setS] = useState<Summary | null>(null);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);

  const load = useCallback(async () => {
    const [p, n] = await Promise.all([fetch("/api/portfolio"), fetch("/api/notifications")]);
    if (p.ok) setS(await p.json());
    if (n.ok) setUnread((await n.json()).unread);
  }, []);

  useEffect(() => {
    load();
    const i = setInterval(load, 15000);
    return () => clearInterval(i);
  }, [load, pathname]);

  useEffect(() => {
    const i = setInterval(async () => {
      if (s?.account.autoTrading && !s.account.killSwitch) {
        await fetch("/api/engine/tick", { method: "POST" });
        load();
      }
    }, 20000);
    return () => clearInterval(i);
  }, [s?.account.autoTrading, s?.account.killSwitch, load]);

  async function kill() {
    await fetch("/api/account", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "killSwitch", enabled: !s?.account.killSwitch }),
    });
    load();
    router.refresh();
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  const live = s?.account.mode === "LIVE";

  return (
    <div className="flex min-h-screen">
      <aside
        className={`fixed inset-y-0 left-0 z-40 w-60 border-r border-[#1c2230] bg-[#0a0d14] p-4 transition-transform lg:translate-x-0 ${open ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="mb-6 flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-sky-500 to-indigo-600 text-sm font-bold text-white">
            TP
          </div>
          <div>
            <div className="text-sm font-semibold text-white">TradePilot AI</div>
            <div className="text-[10px] uppercase tracking-widest text-slate-500">Algo trading suite</div>
          </div>
        </div>
        <nav className="space-y-1">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              onClick={() => setOpen(false)}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition ${
                pathname === n.href
                  ? "bg-sky-500/10 text-sky-300 ring-1 ring-sky-500/30"
                  : "text-slate-400 hover:bg-slate-800/50 hover:text-slate-200"
              }`}
            >
              <span className="text-xs opacity-70">{n.icon}</span>
              {n.label}
            </Link>
          ))}
        </nav>
        <div className="mt-6 border-t border-[#1c2230] pt-4">
          <Button variant={s?.account.killSwitch ? "ghost" : "danger"} className="w-full" onClick={kill}>
            {s?.account.killSwitch ? "RÉARMER LE SYSTÈME" : "⛔ EMERGENCY STOP"}
          </Button>
          <p className="mt-2 text-[10px] leading-snug text-slate-500">
            Arrête le moteur automatique, bloque les nouveaux ordres et annule les ordres en attente.
          </p>
        </div>
        <div className="absolute inset-x-4 bottom-4 text-[11px] text-slate-500">
          <div className="truncate">{userName}</div>
          <button onClick={logout} className="mt-1 text-slate-400 underline hover:text-slate-200">
            Déconnexion
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col lg:ml-60">
        <header className="sticky top-0 z-30 flex flex-wrap items-center gap-3 border-b border-[#1c2230] bg-[#0a0d14]/90 px-4 py-3 backdrop-blur">
          <button className="rounded-md border border-slate-700 px-2 py-1 text-slate-300 lg:hidden" onClick={() => setOpen((o) => !o)}>
            ☰
          </button>
          <div className="num text-sm text-slate-400">
            Capital <span className="font-semibold text-slate-100">{money(s?.metrics.equity ?? 0)}</span>
          </div>
          <div className="num text-sm text-slate-400">
            P&L jour{" "}
            <span className={`font-semibold ${(s?.metrics.dayPnl ?? 0) >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
              {money(s?.metrics.dayPnl ?? 0)}
            </span>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <Link href="/settings" className="text-xs text-slate-400 hover:text-slate-200">
              🔔 {unread}
            </Link>
            <Badge tone={live ? "warn" : "info"}>{live ? "LIVE" : "PAPER"}</Badge>
            <Badge tone={s?.account.autoTrading ? "pos" : "neutral"}>
              AUTO {s?.account.autoTrading ? "ON" : "OFF"}
            </Badge>
            <Badge tone={s?.account.killSwitch ? "neg" : "pos"}>
              {s?.account.killSwitch ? "HALTED" : "SYSTEM OK"}
            </Badge>
          </div>
        </header>
        {s?.account.killSwitch && (
          <div className="border-b border-rose-500/30 bg-rose-500/10 px-4 py-2 text-xs text-rose-300">
            EMERGENCY STOP actif — {s.account.killReason ?? "arrêt manuel"}. Aucun nouvel ordre ne sera envoyé.
          </div>
        )}
        <main className="min-w-0 flex-1 p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
