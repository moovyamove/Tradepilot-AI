"use client";
import type { ReactNode } from "react";

export function Card({
  children,
  className = "",
  title,
  action,
}: {
  children: ReactNode;
  className?: string;
  title?: string;
  action?: ReactNode;
}) {
  return (
    <div className={`card p-4 sm:p-5 ${className}`}>
      {(title || action) && (
        <div className="mb-4 flex items-center justify-between gap-3">
          {title && <h3 className="text-sm font-semibold tracking-wide text-slate-300">{title}</h3>}
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

export function Stat({
  label,
  value,
  sub,
  tone = "neutral",
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: "neutral" | "pos" | "neg" | "warn";
}) {
  const color =
    tone === "pos"
      ? "text-emerald-400"
      : tone === "neg"
        ? "text-rose-400"
        : tone === "warn"
          ? "text-amber-400"
          : "text-slate-100";
  return (
    <div className="card p-4">
      <div className="text-[11px] uppercase tracking-wider text-slate-500">{label}</div>
      <div className={`num mt-1 text-xl font-semibold sm:text-2xl ${color}`}>{value}</div>
      {sub && <div className="mt-1 text-xs text-slate-500">{sub}</div>}
    </div>
  );
}

export function Badge({
  children,
  tone = "neutral",
}: {
  children: ReactNode;
  tone?: "neutral" | "pos" | "neg" | "warn" | "info";
}) {
  const map = {
    neutral: "bg-slate-700/30 text-slate-300 border-slate-600/40",
    pos: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    neg: "bg-rose-500/10 text-rose-400 border-rose-500/30",
    warn: "bg-amber-500/10 text-amber-400 border-amber-500/30",
    info: "bg-sky-500/10 text-sky-400 border-sky-500/30",
  };
  return (
    <span className={`inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-medium ${map[tone]}`}>
      {children}
    </span>
  );
}

export function Button({
  children,
  onClick,
  variant = "primary",
  disabled,
  type = "button",
  className = "",
}: {
  children: ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "danger" | "success";
  disabled?: boolean;
  type?: "button" | "submit";
  className?: string;
}) {
  const map = {
    primary: "bg-sky-600 hover:bg-sky-500 text-white",
    ghost: "bg-slate-800/60 hover:bg-slate-700/60 text-slate-200 border border-slate-700",
    danger: "bg-rose-600 hover:bg-rose-500 text-white",
    success: "bg-emerald-600 hover:bg-emerald-500 text-white",
  };
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`rounded-lg px-3 py-2 text-sm font-medium transition disabled:cursor-not-allowed disabled:opacity-40 ${map[variant]} ${className}`}
    >
      {children}
    </button>
  );
}

export function scoreTone(score: number): "pos" | "warn" | "neg" | "info" | "neutral" {
  if (score >= 80) return "pos";
  if (score >= 65) return "info";
  if (score >= 50) return "warn";
  return "neutral";
}

export function fmt(n: number, d = 2) {
  return n.toLocaleString("fr-FR", { minimumFractionDigits: d, maximumFractionDigits: d });
}

export function money(n: number) {
  return `${n >= 0 ? "" : "-"}$${fmt(Math.abs(n))}`;
}

export function Disclaimer({ text }: { text: string }) {
  return <p className="mt-3 text-[11px] leading-relaxed text-slate-500">{text}</p>;
}
