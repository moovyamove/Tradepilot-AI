"use client";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const axis = { stroke: "#334155", fontSize: 10, tickLine: false };
const tooltip = {
  contentStyle: {
    background: "#0e121a",
    border: "1px solid #1c2230",
    borderRadius: 10,
    fontSize: 12,
    color: "#e2e8f0",
  },
};

export function EquityChart({ data }: { data: { t: string; equity: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={240}>
      <AreaChart data={data}>
        <defs>
          <linearGradient id="eq" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.45} />
            <stop offset="100%" stopColor="#0ea5e9" stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="#161c27" vertical={false} />
        <XAxis dataKey="t" {...axis} hide />
        <YAxis {...axis} domain={["auto", "auto"]} width={60} />
        <Tooltip {...tooltip} />
        <Area type="monotone" dataKey="equity" stroke="#38bdf8" fill="url(#eq)" strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function DrawdownChart({ data }: { data: { t: string; drawdown: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <AreaChart data={data}>
        <CartesianGrid stroke="#161c27" vertical={false} />
        <XAxis dataKey="t" {...axis} hide />
        <YAxis {...axis} width={50} />
        <Tooltip {...tooltip} />
        <Area type="monotone" dataKey="drawdown" stroke="#f43f5e" fill="#f43f5e22" strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function PnlBars({ data }: { data: { label: string; pnl: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={data}>
        <CartesianGrid stroke="#161c27" vertical={false} />
        <XAxis dataKey="label" {...axis} />
        <YAxis {...axis} width={50} />
        <Tooltip {...tooltip} />
        <Bar dataKey="pnl" radius={[3, 3, 0, 0]} fill="#22c55e" />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function PriceChart({ data }: { data: { t: number; c: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <LineChart data={data}>
        <CartesianGrid stroke="#161c27" vertical={false} />
        <XAxis dataKey="t" {...axis} hide />
        <YAxis {...axis} domain={["auto", "auto"]} width={66} />
        <Tooltip {...tooltip} labelFormatter={(v) => new Date(Number(v)).toLocaleString("fr-FR")} />
        <Line type="monotone" dataKey="c" stroke="#38bdf8" dot={false} strokeWidth={2} />
      </LineChart>
    </ResponsiveContainer>
  );
}

export function SimpleCurve({ data }: { data: { i: number; equity: number }[] }) {
  return (
    <ResponsiveContainer width="100%" height={220}>
      <AreaChart data={data}>
        <CartesianGrid stroke="#161c27" vertical={false} />
        <XAxis dataKey="i" {...axis} />
        <YAxis {...axis} domain={["auto", "auto"]} width={60} />
        <Tooltip {...tooltip} />
        <Area type="monotone" dataKey="equity" stroke="#a78bfa" fill="#a78bfa22" strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}
