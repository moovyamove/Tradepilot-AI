import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "TradePilot AI — Assistant de trading algorithmique",
  description:
    "Plateforme SaaS de trading algorithmique: market scanner, opportunity engine, risk engine indépendant, paper trading et backtesting.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <body className="bg-[#07090e] text-slate-200 antialiased">{children}</body>
    </html>
  );
}
