import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { z } from "zod";
import crypto from "crypto";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, ensureUserEnvironment } from "@/lib/auth";
import { audit, notify } from "@/lib/portfolio";
import { rateLimit } from "@/lib/ratelimit";

const schema = z.object({
  email: z.string().email().max(160),
  name: z.string().max(80).optional(),
  password: z.string().min(8).max(128),
});

export async function POST(req: Request) {
  if (!rateLimit(`register:${req.headers.get("x-forwarded-for") ?? "local"}`, 10, 60_000))
    return NextResponse.json({ error: "Trop de tentatives, réessayez plus tard." }, { status: 429 });
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Données invalides (mot de passe: 8 caractères minimum)." }, { status: 400 });
  const email = parsed.data.email.toLowerCase();
  const [existing] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (existing) return NextResponse.json({ error: "Un compte existe déjà avec cet email." }, { status: 409 });
  const passwordHash = await bcrypt.hash(parsed.data.password, 10);
  const verifyToken = crypto.randomBytes(24).toString("hex");
  const [u] = await db
    .insert(users)
    .values({ email, name: parsed.data.name ?? email.split("@")[0], passwordHash, verifyToken })
    .returning();
  await ensureUserEnvironment(u.id);
  await createSession(u.id);
  await notify(u.id, "info", "Bienvenue sur TradePilot AI", "Mode PAPER activé par défaut. Le mode LIVE reste désactivé.");
  await audit(u.id, "USER_REGISTERED", { email });
  return NextResponse.json({ ok: true, verifyUrl: `/api/auth/verify?token=${verifyToken}` });
}
