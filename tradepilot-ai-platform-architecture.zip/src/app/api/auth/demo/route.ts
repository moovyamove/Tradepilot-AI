import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, ensureUserEnvironment } from "@/lib/auth";
import { seedDemoData } from "@/lib/seed";

export async function POST() {
  const email = "demo@tradepilot.ai";
  let [u] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!u) {
    [u] = await db
      .insert(users)
      .values({
        email,
        name: "Compte démo",
        passwordHash: await bcrypt.hash("demo12345", 10),
        emailVerified: true,
      })
      .returning();
  }
  await ensureUserEnvironment(u.id);
  await seedDemoData(u.id);
  await createSession(u.id);
  return NextResponse.json({ ok: true });
}
