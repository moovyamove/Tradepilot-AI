import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";

export async function GET(req: Request) {
  const token = new URL(req.url).searchParams.get("token");
  if (!token) return NextResponse.json({ error: "Token manquant." }, { status: 400 });
  const [u] = await db.select().from(users).where(eq(users.verifyToken, token)).limit(1);
  if (!u) return NextResponse.json({ error: "Token invalide." }, { status: 404 });
  await db.update(users).set({ emailVerified: true, verifyToken: null }).where(eq(users.id, u.id));
  return NextResponse.redirect(new URL("/dashboard", req.url));
}
