import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { audit } from "@/lib/portfolio";
import { rateLimit } from "@/lib/ratelimit";

const forgot = z.object({ action: z.literal("forgot"), email: z.string().email() });
const reset = z.object({
  action: z.literal("reset"),
  token: z.string().min(10),
  password: z.string().min(8).max(128),
});

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for") ?? "local";
  if (!rateLimit(`pwd:${ip}`, 10, 60_000))
    return NextResponse.json({ error: "Trop de requêtes." }, { status: 429 });
  const body = await req.json().catch(() => null);
  const f = forgot.safeParse(body);
  if (f.success) {
    const [u] = await db.select().from(users).where(eq(users.email, f.data.email.toLowerCase())).limit(1);
    if (!u) return NextResponse.json({ ok: true }); // no account enumeration
    const token = crypto.randomBytes(24).toString("hex");
    await db.update(users).set({ resetToken: token }).where(eq(users.id, u.id));
    await audit(u.id, "PASSWORD_RESET_REQUESTED", {});
    // In production this link is emailed; exposed here for the sandbox environment.
    return NextResponse.json({ ok: true, resetToken: token });
  }
  const r = reset.safeParse(body);
  if (r.success) {
    const [u] = await db.select().from(users).where(eq(users.resetToken, r.data.token)).limit(1);
    if (!u) return NextResponse.json({ error: "Token invalide." }, { status: 404 });
    await db
      .update(users)
      .set({ passwordHash: await bcrypt.hash(r.data.password, 10), resetToken: null })
      .where(eq(users.id, u.id));
    await audit(u.id, "PASSWORD_RESET", {});
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
}
