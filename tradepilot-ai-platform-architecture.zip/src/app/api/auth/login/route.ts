import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { createSession, ensureUserEnvironment } from "@/lib/auth";
import { audit } from "@/lib/portfolio";
import { rateLimit } from "@/lib/ratelimit";

const schema = z.object({ email: z.string().email(), password: z.string().min(1) });

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for") ?? "local";
  if (!rateLimit(`login:${ip}`, 15, 60_000))
    return NextResponse.json({ error: "Trop de tentatives de connexion." }, { status: 429 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Données invalides." }, { status: 400 });
  const [u] = await db
    .select()
    .from(users)
    .where(eq(users.email, parsed.data.email.toLowerCase()))
    .limit(1);
  if (!u || !(await bcrypt.compare(parsed.data.password, u.passwordHash)))
    return NextResponse.json({ error: "Identifiants invalides." }, { status: 401 });
  await ensureUserEnvironment(u.id);
  await createSession(u.id);
  await audit(u.id, "USER_LOGIN", { ip });
  return NextResponse.json({ ok: true });
}
