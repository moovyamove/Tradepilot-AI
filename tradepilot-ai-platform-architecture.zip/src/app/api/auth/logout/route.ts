import { NextResponse } from "next/server";
import { destroySession, getUserId } from "@/lib/auth";
import { audit } from "@/lib/portfolio";

export async function POST() {
  const uid = await getUserId();
  await destroySession();
  if (uid) await audit(uid, "USER_LOGOUT", {});
  return NextResponse.json({ ok: true });
}
