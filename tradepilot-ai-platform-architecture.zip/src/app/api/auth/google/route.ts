import { NextResponse } from "next/server";

/**
 * Google OAuth entrypoint. Requires GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET
 * (see .env.example). Secrets are read server-side only.
 */
export async function GET(req: Request) {
  const clientId = process.env.GOOGLE_CLIENT_ID;
  if (!clientId) {
    return NextResponse.json(
      { error: "Google OAuth non configuré. Renseignez GOOGLE_CLIENT_ID et GOOGLE_CLIENT_SECRET." },
      { status: 400 },
    );
  }
  const redirectUri = new URL("/api/auth/google/callback", req.url).toString();
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.searchParams.set("client_id", clientId);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "openid email profile");
  url.searchParams.set("prompt", "select_account");
  return NextResponse.redirect(url.toString());
}
