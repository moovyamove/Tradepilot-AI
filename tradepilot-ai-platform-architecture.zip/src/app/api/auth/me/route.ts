import { NextResponse } from "next/server";
import { requireUser } from "@/lib/auth";

export async function GET() {
  const u = await requireUser();
  if (!u) return NextResponse.json({ user: null }, { status: 401 });
  return NextResponse.json({
    user: { id: u.id, email: u.email, name: u.name, emailVerified: u.emailVerified, provider: u.provider },
  });
}
