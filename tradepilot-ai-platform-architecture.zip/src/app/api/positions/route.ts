import { NextResponse } from "next/server";
import { z } from "zod";
import { getUserId } from "@/lib/auth";
import { closePosition, syncPortfolio } from "@/lib/portfolio";
import { lastPrice } from "@/lib/market";

export const dynamic = "force-dynamic";

export async function GET() {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const { openPositions, state } = await syncPortfolio(uid);
  return NextResponse.json({ positions: openPositions, state });
}

export async function POST(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const parsed = z.object({ id: z.number().int() }).safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
  const { openPositions } = await syncPortfolio(uid);
  const p = openPositions.find((x) => x.id === parsed.data.id);
  if (!p) return NextResponse.json({ error: "Position introuvable." }, { status: 404 });
  const pnl = await closePosition(uid, p.id, lastPrice(p.symbol), "MANUAL");
  return NextResponse.json({ ok: true, pnl });
}
