import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { getUserId } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const rows = await db
    .select()
    .from(auditLogs)
    .where(eq(auditLogs.userId, uid))
    .orderBy(desc(auditLogs.createdAt))
    .limit(100);
  return NextResponse.json({ logs: rows });
}
