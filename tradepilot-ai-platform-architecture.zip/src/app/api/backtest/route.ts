import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { backtests } from "@/db/schema";
import { getUserId } from "@/lib/auth";
import { getRisk } from "@/lib/portfolio";
import { runBacktest } from "@/lib/backtest";

export const dynamic = "force-dynamic";

const schema = z.object({
  symbol: z.string().min(2).max(20),
  bars: z.number().int().min(200).max(3000),
  strategy: z.string().max(40).default("ALL"),
  startingBalance: z.number().min(100).max(1_000_000).default(10000),
});

export async function GET() {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const rows = await db
    .select()
    .from(backtests)
    .where(eq(backtests.userId, uid))
    .orderBy(desc(backtests.createdAt))
    .limit(10);
  return NextResponse.json({ backtests: rows });
}

export async function POST(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
  const cfg = await getRisk(uid);
  const result = runBacktest(
    parsed.data.symbol,
    parsed.data.bars,
    cfg,
    parsed.data.startingBalance,
    parsed.data.strategy,
  );
  await db.insert(backtests).values({
    userId: uid,
    symbol: parsed.data.symbol,
    strategy: result.strategy,
    bars: parsed.data.bars,
    result,
  });
  return NextResponse.json({ result });
}
