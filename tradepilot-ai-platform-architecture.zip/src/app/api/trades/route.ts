import { NextResponse } from "next/server";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { trades } from "@/db/schema";
import { getUserId } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const sp = new URL(req.url).searchParams;
  const filters = [eq(trades.userId, uid)];
  const symbol = sp.get("symbol");
  const direction = sp.get("direction");
  const strategy = sp.get("strategy");
  const reason = sp.get("reason");
  if (symbol && symbol !== "ALL") filters.push(eq(trades.symbol, symbol));
  if (direction && direction !== "ALL") filters.push(eq(trades.direction, direction));
  if (strategy && strategy !== "ALL") filters.push(eq(trades.strategy, strategy));
  if (reason && reason !== "ALL") filters.push(eq(trades.exitReason, reason));
  const rows = await db
    .select()
    .from(trades)
    .where(and(...filters))
    .orderBy(desc(trades.closedAt))
    .limit(300);
  return NextResponse.json({ trades: rows });
}
