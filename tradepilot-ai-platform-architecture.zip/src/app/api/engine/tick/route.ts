import { NextResponse } from "next/server";
import { getUserId } from "@/lib/auth";
import { syncPortfolio } from "@/lib/portfolio";
import { scanAll } from "@/lib/scanner";
import { buildOpportunity } from "@/lib/opportunity";
import { evaluateTrade } from "@/lib/risk";
import { db } from "@/db";
import { positions } from "@/db/schema";
import { and, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/** Auto-trading engine tick: scans, validates via Risk Engine, executes at most one trade. */
export async function POST(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const { acc, cfg, state } = await syncPortfolio(uid);
  if (acc.killSwitch) return NextResponse.json({ ran: false, reason: "Kill switch actif." });
  if (!acc.autoTrading) return NextResponse.json({ ran: false, reason: "Auto trading OFF." });

  const open = await db
    .select()
    .from(positions)
    .where(and(eq(positions.userId, uid), eq(positions.status, "OPEN")));
  const held = new Set(open.map((p) => p.symbol));

  const candidates = scanAll()
    .filter((s) => !held.has(s.symbol))
    .map(buildOpportunity)
    .filter((o): o is NonNullable<typeof o> => o !== null)
    .sort((a, b) => b.score - a.score);

  for (const o of candidates) {
    const d = evaluateTrade(
      { entry: o.entry, stopLoss: o.stopLoss, takeProfit: o.takeProfit, riskReward: o.riskReward, score: o.score, symbol: o.symbol },
      cfg,
      state,
    );
    if (d.approved) {
      const res = await fetch(new URL("/api/trade/execute", req.url), {
        method: "POST",
        headers: { "content-type": "application/json", cookie: req.headers.get("cookie") ?? "" },
        body: JSON.stringify({ symbol: o.symbol }),
      });
      const json = await res.json();
      return NextResponse.json({ ran: true, executed: json.executed === true, symbol: o.symbol });
    }
  }
  return NextResponse.json({ ran: true, executed: false, reason: "Aucune opportunité validée par le Risk Engine." });
}
