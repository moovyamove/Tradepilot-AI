import { NextResponse } from "next/server";
import { getUserId } from "@/lib/auth";
import { scanAll } from "@/lib/scanner";
import { buildOpportunity } from "@/lib/opportunity";
import { syncPortfolio } from "@/lib/portfolio";
import { evaluateTrade } from "@/lib/risk";

export const dynamic = "force-dynamic";

export async function GET() {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const { cfg, state } = await syncPortfolio(uid);
  const opps = scanAll()
    .map(buildOpportunity)
    .filter((o): o is NonNullable<typeof o> => o !== null)
    .map((o) => {
      const decision = evaluateTrade(
        { entry: o.entry, stopLoss: o.stopLoss, takeProfit: o.takeProfit, riskReward: o.riskReward, score: o.score, symbol: o.symbol },
        cfg,
        state,
      );
      return { ...o, decision };
    });
  return NextResponse.json({ opportunities: opps, risk: cfg, state });
}
