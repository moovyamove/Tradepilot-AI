import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { apiConnections } from "@/db/schema";
import { getUserId } from "@/lib/auth";
import { encryptSecret, maskKey } from "@/lib/crypto";
import { audit } from "@/lib/portfolio";
import { getAdapter, listAdapters } from "@/lib/brokers";

export const dynamic = "force-dynamic";

const schema = z.object({
  broker: z.string().min(2).max(40),
  environment: z.enum(["SANDBOX", "LIVE"]),
  label: z.string().max(60).default(""),
  apiKey: z.string().min(8).max(200),
  apiSecret: z.string().min(8).max(400),
});

export async function GET() {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const rows = await db.select().from(apiConnections).where(eq(apiConnections.userId, uid));
  // API keys never leave the server: only a masked preview is returned.
  const safe = rows.map((r) => ({
    id: r.id,
    broker: r.broker,
    environment: r.environment,
    label: r.label,
    keyPreview: r.keyPreview,
    active: r.active,
    withdrawalDisabled: r.withdrawalDisabled,
    createdAt: r.createdAt,
  }));
  const health = await getAdapter("binance-testnet").healthCheck();
  return NextResponse.json({ connections: safe, adapters: listAdapters(), health });
}

export async function POST(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Données invalides." }, { status: 400 });
  const [row] = await db
    .insert(apiConnections)
    .values({
      userId: uid,
      broker: parsed.data.broker,
      environment: parsed.data.environment,
      label: parsed.data.label,
      apiKeyEnc: encryptSecret(parsed.data.apiKey),
      apiSecretEnc: encryptSecret(parsed.data.apiSecret),
      keyPreview: maskKey(parsed.data.apiKey),
      active: parsed.data.environment === "SANDBOX",
    })
    .returning();
  await audit(uid, "API_CONNECTION_ADDED", { broker: parsed.data.broker, env: parsed.data.environment });
  return NextResponse.json({ ok: true, id: row.id });
}

export async function DELETE(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const id = Number(new URL(req.url).searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "id requis" }, { status: 400 });
  await db.delete(apiConnections).where(and(eq(apiConnections.id, id), eq(apiConnections.userId, uid)));
  await audit(uid, "API_CONNECTION_DELETED", { id });
  return NextResponse.json({ ok: true });
}
