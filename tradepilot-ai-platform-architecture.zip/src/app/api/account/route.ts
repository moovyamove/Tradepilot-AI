import { NextResponse } from "next/server";
import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { accounts, orders, positions } from "@/db/schema";
import { getUserId } from "@/lib/auth";
import { audit, getAccount, notify } from "@/lib/portfolio";

export const dynamic = "force-dynamic";

const schema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("setMode"), mode: z.enum(["PAPER", "LIVE"]), confirm: z.boolean().optional() }),
  z.object({ action: z.literal("setAutoTrading"), enabled: z.boolean() }),
  z.object({ action: z.literal("killSwitch"), enabled: z.boolean() }),
  z.object({ action: z.literal("resetPaper") }),
]);

export async function POST(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
  const acc = await getAccount(uid);
  const d = parsed.data;

  if (d.action === "setMode") {
    if (d.mode === "LIVE" && !d.confirm)
      return NextResponse.json(
        { error: "Confirmation explicite requise pour activer le mode LIVE." },
        { status: 400 },
      );
    if (d.mode === "LIVE" && acc.killSwitch)
      return NextResponse.json({ error: "Kill switch actif: mode LIVE impossible." }, { status: 400 });
    await db.update(accounts).set({ mode: d.mode, autoTrading: false }).where(eq(accounts.id, acc.id));
    await notify(uid, d.mode === "LIVE" ? "warning" : "info", `Mode ${d.mode} activé`, "Auto-trading remis à OFF par sécurité.");
    await audit(uid, "MODE_CHANGED", { mode: d.mode });
  }

  if (d.action === "setAutoTrading") {
    if (d.enabled && acc.killSwitch)
      return NextResponse.json({ error: "Kill switch actif: auto-trading impossible." }, { status: 400 });
    await db.update(accounts).set({ autoTrading: d.enabled }).where(eq(accounts.id, acc.id));
    await notify(uid, d.enabled ? "warning" : "info", `Auto trading ${d.enabled ? "ON" : "OFF"}`, d.enabled ? "Tous les ordres passent obligatoirement par le Risk Engine." : "Aucun ordre ne sera envoyé.");
    await audit(uid, "AUTO_TRADING", { enabled: d.enabled });
  }

  if (d.action === "killSwitch") {
    await db
      .update(accounts)
      .set({
        killSwitch: d.enabled,
        autoTrading: false,
        killReason: d.enabled ? "EMERGENCY STOP manuel" : null,
      })
      .where(eq(accounts.id, acc.id));
    if (d.enabled) {
      await db
        .update(orders)
        .set({ status: "CANCELLED" })
        .where(and(eq(orders.userId, uid), eq(orders.status, "PENDING")));
    }
    await notify(uid, d.enabled ? "danger" : "info", d.enabled ? "EMERGENCY STOP activé" : "Système réarmé", d.enabled ? "Moteur automatique arrêté, ordres en attente annulés." : "Les contrôles de risque restent actifs.");
    await audit(uid, "KILL_SWITCH", { enabled: d.enabled });
  }

  if (d.action === "resetPaper") {
    await db
      .update(positions)
      .set({ status: "CLOSED" })
      .where(and(eq(positions.userId, uid), eq(positions.status, "OPEN")));
    await db
      .update(accounts)
      .set({
        balance: acc.startingBalance,
        equityPeak: acc.startingBalance,
        dayAnchorEquity: acc.startingBalance,
        consecutiveLosses: 0,
        killSwitch: false,
        killReason: null,
        autoTrading: false,
      })
      .where(eq(accounts.id, acc.id));
    await audit(uid, "PAPER_RESET", {});
  }

  return NextResponse.json({ ok: true, account: await getAccount(uid) });
}
