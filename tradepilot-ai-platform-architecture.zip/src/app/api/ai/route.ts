import { NextResponse } from "next/server";
import { z } from "zod";
import { getUserId } from "@/lib/auth";
import { getStats, syncPortfolio } from "@/lib/portfolio";
import { analyze } from "@/lib/scanner";
import { buildOpportunity } from "@/lib/opportunity";
import { evaluateTrade } from "@/lib/risk";
import { rateLimit } from "@/lib/ratelimit";

export const dynamic = "force-dynamic";

const schema = z.object({ question: z.string().min(2).max(500), symbol: z.string().max(20).optional() });

/**
 * Explainability assistant. It is strictly read-only: it can explain decisions
 * but has NO authority to place orders or override the risk engine.
 */
export async function POST(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!rateLimit(`ai:${uid}`, 30, 60_000))
    return NextResponse.json({ error: "Trop de requêtes." }, { status: 429 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Requête invalide." }, { status: 400 });
  const q = parsed.data.question.toLowerCase();
  const stats = await getStats(uid);
  const { cfg, state } = await syncPortfolio(uid);
  const lines: string[] = [];

  const symbol = parsed.data.symbol;
  if (symbol && (q.includes("pourquoi") || q.includes("opport") || q.includes("refus") || q.includes("analys"))) {
    const scan = analyze(symbol);
    const opp = buildOpportunity(scan);
    lines.push(`**${symbol}** — score ${scan.score}/100 (${scan.grade}), stratégie: ${scan.strategy}.`);
    lines.push(...scan.reasons.map((r) => `• ${r}`));
    if (opp) {
      const d = evaluateTrade(
        { entry: opp.entry, stopLoss: opp.stopLoss, takeProfit: opp.takeProfit, riskReward: opp.riskReward, score: opp.score, symbol },
        cfg,
        state,
      );
      lines.push(
        d.approved
          ? `Le Risk Engine **autorise** ce trade: taille ${d.size} (risque ${d.riskAmount} USD, soit ${cfg.riskPerTradePct}% du capital).`
          : `Le Risk Engine **refuse** ce trade: ${d.rejectionReasons.join(" | ")}`,
      );
    } else {
      lines.push("Aucun plan de trade valide: la configuration actuelle ne produit pas d'entrée exploitable.");
    }
  } else if (q.includes("risque") || q.includes("limite") || q.includes("drawdown")) {
    lines.push(
      `Capital ${stats.metrics.equity} USD. Drawdown courant ${stats.metrics.drawdownPct}% (limite ${cfg.maxDrawdownPct}%).`,
      `Perte du jour utilisée: ${stats.metrics.dailyLossUsedPct}% sur ${cfg.maxDailyLossPct}% autorisés.`,
      `Exposition ${stats.metrics.exposurePct}% / ${cfg.maxExposurePct}% — risque engagé ${stats.metrics.riskInMarketPct}%.`,
      `Positions ouvertes ${stats.openPositions.length}/${cfg.maxOpenPositions}, pertes consécutives ${stats.account.consecutiveLosses}/${cfg.maxConsecutiveLosses}.`,
    );
  } else if (q.includes("performance") || q.includes("résumé") || q.includes("resume") || q.includes("bilan")) {
    lines.push(
      `Sur ${stats.metrics.trades} trades clôturés: ${stats.metrics.wins} gagnants / ${stats.metrics.losses} perdants (taux de réussite ${stats.metrics.winRate}%).`,
      `P&L total ${stats.metrics.totalPnl} USD, P&L du jour ${stats.metrics.dayPnl} USD, profit factor ${stats.metrics.profitFactor}.`,
      `Gain moyen ${stats.metrics.avgWin} USD, perte moyenne ${stats.metrics.avgLoss} USD, drawdown max ${stats.metrics.maxDrawdownPct}%.`,
    );
  } else if (q.includes("ferm")) {
    const last = stats.recentTrades[0];
    lines.push(
      last
        ? `Dernière position fermée: ${last.symbol} ${last.direction}, sortie à ${last.exit} pour cause de ${last.exitReason}, P&L ${last.pnl.toFixed(2)} USD. Les sorties sont déclenchées par le stop-loss, le take-profit ou une fermeture manuelle — jamais en déplaçant le stop contre la position.`
        : "Aucune position fermée pour le moment.",
    );
  } else {
    lines.push(
      "Je peux expliquer: pourquoi une opportunité est détectée, pourquoi un trade est refusé, l'état du risque, les fermetures de positions et un résumé de performance.",
      `État actuel: mode ${state.mode}, auto-trading ${state.autoTrading ? "ON" : "OFF"}, kill switch ${state.killSwitch ? "ACTIF" : "inactif"}.`,
    );
  }

  lines.push(
    "_Analyse explicative uniquement. Aucune garantie de profit. L'assistant ne peut ni contourner le Risk Engine ni envoyer d'ordres._",
  );
  return NextResponse.json({ answer: lines.join("\n") });
}
