import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { orders, positions, signals } from "@/db/schema";
import { getUserId } from "@/lib/auth";
import { analyze } from "@/lib/scanner";
import { buildOpportunity } from "@/lib/opportunity";
import { audit, notify, syncPortfolio } from "@/lib/portfolio";
import { evaluateTrade } from "@/lib/risk";
import { getAdapter } from "@/lib/brokers";
import { rateLimit } from "@/lib/ratelimit";

const schema = z.object({ symbol: z.string().min(2).max(20), dryRun: z.boolean().optional() });

export async function POST(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  if (!rateLimit(`exec:${uid}`, 30, 60_000))
    return NextResponse.json({ error: "Trop d'ordres envoyés, ralentissez." }, { status: 429 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Requête invalide." }, { status: 400 });

  // 1-3: Market scanner -> strategy engine -> opportunity score
  const scan = analyze(parsed.data.symbol);
  const opp = buildOpportunity(scan);
  if (!opp)
    return NextResponse.json(
      { approved: false, rejectionReasons: ["Aucune opportunité exploitable sur cet actif actuellement."], checks: [] },
      { status: 200 },
    );

  // 4-9: Risk engine with full validation pipeline (independent veto authority)
  const { acc, cfg, state } = await syncPortfolio(uid);
  const decision = evaluateTrade(
    { entry: opp.entry, stopLoss: opp.stopLoss, takeProfit: opp.takeProfit, riskReward: opp.riskReward, score: opp.score, symbol: opp.symbol },
    cfg,
    state,
  );

  if (!decision.approved || parsed.data.dryRun) {
    if (!decision.approved) {
      await notify(uid, "warning", `Trade refusé: ${opp.symbol}`, decision.rejectionReasons[0] ?? "");
      await audit(uid, "TRADE_REJECTED", { symbol: opp.symbol, reasons: decision.rejectionReasons });
    }
    return NextResponse.json({ opportunity: opp, ...decision, executed: false });
  }

  // 10: Execution through broker adapter
  const adapter = getAdapter(acc.mode === "LIVE" ? "binance-testnet" : "paper");
  const health = await adapter.healthCheck();
  if (!health.ok)
    return NextResponse.json(
      { approved: false, executed: false, rejectionReasons: ["Connexion broker indisponible."], checks: decision.checks },
      { status: 200 },
    );
  const fill = await adapter.createOrder({
    symbol: opp.symbol,
    side: opp.direction,
    type: "MARKET",
    size: decision.size,
    price: opp.entry,
  });

  const [sig] = await db
    .insert(signals)
    .values({
      userId: uid,
      symbol: opp.symbol,
      direction: opp.direction,
      entry: opp.entry,
      stopLoss: opp.stopLoss,
      takeProfit: opp.takeProfit,
      riskReward: opp.riskReward,
      score: opp.score,
      strategy: opp.strategy,
      reasons: opp.reasons,
      metrics: opp.metrics,
      status: "EXECUTED",
    })
    .returning();

  await db.insert(orders).values({
    userId: uid,
    symbol: opp.symbol,
    side: opp.direction,
    type: "MARKET",
    price: fill.filledPrice,
    size: decision.size,
    status: "FILLED",
    broker: adapter.id,
  });

  const [pos] = await db
    .insert(positions)
    .values({
      userId: uid,
      signalId: sig.id,
      symbol: opp.symbol,
      direction: opp.direction,
      mode: acc.mode,
      entry: fill.filledPrice,
      stopLoss: opp.stopLoss,
      takeProfit: opp.takeProfit,
      size: decision.size,
      notional: decision.notional,
      riskAmount: decision.riskAmount,
      strategy: opp.strategy,
      score: opp.score,
    })
    .returning();

  await notify(
    uid,
    "success",
    `Trade exécuté ${opp.direction} ${opp.symbol}`,
    `Taille ${decision.size} | Risque ${decision.riskAmount} USD | R:R 1:${opp.riskReward}`,
  );
  await audit(uid, "TRADE_EXECUTED", { positionId: pos.id, symbol: opp.symbol, mode: acc.mode });

  return NextResponse.json({ opportunity: opp, ...decision, executed: true, position: pos });
}
