import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { riskSettings } from "@/db/schema";
import { getUserId } from "@/lib/auth";
import { audit, getRisk } from "@/lib/portfolio";

export const dynamic = "force-dynamic";

const schema = z.object({
  riskPerTradePct: z.number().min(0.05).max(5),
  maxDailyLossPct: z.number().min(0.5).max(20),
  maxDrawdownPct: z.number().min(1).max(50),
  maxOpenPositions: z.number().int().min(1).max(20),
  maxExposurePct: z.number().min(1).max(300),
  maxPositionSizePct: z.number().min(1).max(100),
  maxConsecutiveLosses: z.number().int().min(1).max(20),
  minRiskReward: z.number().min(1).max(10),
  minScore: z.number().int().min(50).max(100),
});

export async function GET() {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  return NextResponse.json({ risk: await getRisk(uid) });
}

export async function PUT(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success)
    return NextResponse.json({ error: "Paramètres hors des bornes autorisées." }, { status: 400 });
  await db.update(riskSettings).set(parsed.data).where(eq(riskSettings.userId, uid));
  await audit(uid, "RISK_SETTINGS_UPDATED", parsed.data);
  return NextResponse.json({ ok: true, risk: await getRisk(uid) });
}
