import { NextResponse } from "next/server";
import { getUserId } from "@/lib/auth";
import { scanAll, analyze } from "@/lib/scanner";
import { getCandles } from "@/lib/market";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  const symbol = new URL(req.url).searchParams.get("symbol");
  if (symbol) {
    const candles = getCandles(symbol, 200);
    return NextResponse.json({
      scan: analyze(symbol),
      candles: candles.map((c) => ({ t: c.t, c: Number(c.c.toFixed(6)), v: c.v })),
    });
  }
  return NextResponse.json({ results: scanAll(), scannedAt: new Date().toISOString() });
}
