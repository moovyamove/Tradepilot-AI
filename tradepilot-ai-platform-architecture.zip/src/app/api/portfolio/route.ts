import { NextResponse } from "next/server";
import { getUserId } from "@/lib/auth";
import { getStats } from "@/lib/portfolio";

export const dynamic = "force-dynamic";

export async function GET() {
  const uid = await getUserId();
  if (!uid) return NextResponse.json({ error: "Non authentifié" }, { status: 401 });
  return NextResponse.json(await getStats(uid));
}
