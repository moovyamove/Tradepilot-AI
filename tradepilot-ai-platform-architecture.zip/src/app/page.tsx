import Link from "next/link";
import { getUserId } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function Home() {
  if (await getUserId()) redirect("/dashboard");
  const features = [
    ["Market Scanner", "Tendance, momentum, volatilité, volume, structure, RSI, MACD, ATR, breakouts et pullbacks sur plusieurs actifs."],
    ["Opportunity Engine", "Plan de trade complet: entrée, stop-loss, take-profit, ratio risque/rendement, score 0–100 et raisons détaillées."],
    ["Risk Engine indépendant", "Un moteur séparé qui peut REFUSER toute opération. Taille calculée depuis capital × risque / distance de stop."],
    ["Paper Trading", "Simulez, mesurez le drawdown et testez vos configurations sans argent réel. Le mode LIVE est désactivé par défaut."],
    ["Strategy Lab", "Backtests avec rendement, profit factor, win rate, expectancy, drawdown max et Sharpe."],
    ["Kill Switch", "Arrêt d'urgence manuel et arrêts automatiques sur perte quotidienne, drawdown ou anomalie broker."],
  ];
  return (
    <main className="mx-auto max-w-6xl px-6 py-16">
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 font-bold text-white">
          TP
        </div>
        <span className="text-lg font-semibold text-white">TradePilot AI</span>
      </div>
      <h1 className="mt-12 max-w-3xl text-4xl font-semibold leading-tight text-white sm:text-5xl">
        L&apos;automatisation du trading, encadrée par un moteur de risque qui a le dernier mot.
      </h1>
      <p className="mt-5 max-w-2xl text-slate-400">
        TradePilot AI analyse les marchés, identifie des opportunités, calcule automatiquement la taille de position
        et n&apos;exécute un ordre que si toutes les conditions de sécurité sont validées.
      </p>
      <div className="mt-8 flex flex-wrap gap-3">
        <Link href="/login" className="rounded-lg bg-sky-600 px-5 py-3 text-sm font-medium text-white hover:bg-sky-500">
          Ouvrir la plateforme
        </Link>
        <Link href="/login?demo=1" className="rounded-lg border border-slate-700 px-5 py-3 text-sm text-slate-200 hover:bg-slate-800">
          Essayer le compte démo
        </Link>
      </div>
      <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {features.map(([t, d]) => (
          <div key={t} className="card p-5">
            <h3 className="text-sm font-semibold text-white">{t}</h3>
            <p className="mt-2 text-xs leading-relaxed text-slate-400">{d}</p>
          </div>
        ))}
      </div>
      <p className="mt-12 text-xs leading-relaxed text-slate-500">
        TradePilot AI est un outil logiciel d&apos;automatisation du trading. Il ne promet ni ne garantit aucun gain.
        Le trading comporte un risque de perte en capital. Toute exécution réelle reste soumise aux limites de risque configurées.
      </p>
    </main>
  );
}
