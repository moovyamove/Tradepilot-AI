"use client";
import { useCallback, useEffect, useState } from "react";
import { Badge, Button, Card, Disclaimer } from "@/components/ui";

type Conn = {
  id: number;
  broker: string;
  environment: string;
  label: string;
  keyPreview: string;
  active: boolean;
  withdrawalDisabled: boolean;
  createdAt: string;
};
type Adapter = { id: string; name: string; kind: string; environments: string[]; requiredPermissions: string[] };

export default function Connections() {
  const [conns, setConns] = useState<Conn[]>([]);
  const [adapters, setAdapters] = useState<Adapter[]>([]);
  const [health, setHealth] = useState<{ ok: boolean; latencyMs: number; detail: string } | null>(null);
  const [form, setForm] = useState({ broker: "binance-testnet", environment: "SANDBOX", label: "", apiKey: "", apiSecret: "" });
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    const r = await fetch("/api/connections");
    if (r.ok) {
      const j = await r.json();
      setConns(j.connections);
      setAdapters(j.adapters);
      setHealth(j.health);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function add() {
    const r = await fetch("/api/connections", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(form),
    });
    const j = await r.json();
    setMsg(r.ok ? "Connexion enregistrée. Les clés sont chiffrées (AES-256-GCM) côté serveur." : j.error);
    setForm({ ...form, apiKey: "", apiSecret: "" });
    load();
  }

  async function del(id: number) {
    await fetch(`/api/connections?id=${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">API Connections</h1>
        <p className="text-xs text-slate-500">
          Architecture multi-brokers (BrokerAdapter / ExchangeAdapter). Aucune permission de retrait n&apos;est demandée.
        </p>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Connecteurs disponibles">
          <div className="space-y-3">
            {adapters.map((a) => (
              <div key={a.id} className="rounded-lg border border-slate-800 p-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-200">{a.name}</span>
                  <Badge tone="info">{a.environments.join(" / ")}</Badge>
                </div>
                <div className="mt-1 text-[11px] text-slate-500">
                  Type: {a.kind} · Permissions requises: {a.requiredPermissions.join(", ")} (jamais de retrait)
                </div>
              </div>
            ))}
            {health && (
              <div className="text-[11px] text-slate-500">
                Health check sandbox: {health.ok ? "✅ OK" : "❌ KO"} · {health.latencyMs} ms · {health.detail}
              </div>
            )}
          </div>
        </Card>

        <Card title="Ajouter une connexion (TESTNET / SANDBOX)">
          <div className="space-y-3 text-xs">
            <select
              value={form.broker}
              onChange={(e) => setForm({ ...form, broker: e.target.value })}
              className="w-full rounded-md border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100"
            >
              {adapters.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}
            </select>
            <select
              value={form.environment}
              onChange={(e) => setForm({ ...form, environment: e.target.value })}
              className="w-full rounded-md border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100"
            >
              <option value="SANDBOX">SANDBOX / TESTNET</option>
              <option value="LIVE">LIVE (après validation complète)</option>
            </select>
            <input placeholder="Libellé" value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} className="w-full rounded-md border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100" />
            <input placeholder="API Key" value={form.apiKey} onChange={(e) => setForm({ ...form, apiKey: e.target.value })} className="w-full rounded-md border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100" />
            <input type="password" placeholder="API Secret" value={form.apiSecret} onChange={(e) => setForm({ ...form, apiSecret: e.target.value })} className="w-full rounded-md border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100" />
            <Button onClick={add}>Enregistrer la connexion</Button>
            {msg && <div className="text-sky-400">{msg}</div>}
          </div>
          <Disclaimer text="Les clés sont chiffrées en AES-256-GCM côté serveur et ne sont jamais renvoyées au navigateur. N'activez jamais la permission de retrait de fonds." />
        </Card>
      </div>

      <Card title="Connexions enregistrées">
        {conns.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune connexion. Le moteur fonctionne en Paper Trading local.</p>
        ) : (
          <div className="space-y-2">
            {conns.map((c) => (
              <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 rounded-lg border border-slate-800 p-3 text-xs">
                <div>
                  <div className="text-slate-200">{c.label || c.broker}</div>
                  <div className="num text-slate-500">{c.broker} · {c.keyPreview}</div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={c.environment === "LIVE" ? "warn" : "info"}>{c.environment}</Badge>
                  <Badge tone={c.withdrawalDisabled ? "pos" : "neg"}>Retrait désactivé</Badge>
                  <Button variant="ghost" onClick={() => del(c.id)}>Supprimer</Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
