"use client";
import { useCallback, useEffect, useState } from "react";
import { Badge, Card, Disclaimer, fmt, scoreTone } from "@/components/ui";
import { PriceChart } from "@/components/Charts";

type Scan = {
  symbol: string;
  name: string;
  kind: string;
  score: number;
  grade: string;
  direction: string;
  strategy: string;
  reasons: string[];
  metrics: {
    price: number;
    trend: string;
    rsi: number;
    macdHist: number;
    atrPct: number;
    volumeRatio: number;
    support: number;
    resistance: number;
    structure: string;
    change24h: number;
    momentum: number;
    volatility: number;
    ema20: number;
    ema50: number;
    sma200: number;
    breakout: boolean;
    pullback: boolean;
  };
};

export default function Markets() {
  const [rows, setRows] = useState<Scan[]>([]);
  const [sel, setSel] = useState<string | null>(null);
  const [detail, setDetail] = useState<{ scan: Scan; candles: { t: number; c: number }[] } | null>(null);

  const load = useCallback(async () => {
    const r = await fetch("/api/scan");
    if (r.ok) {
      const j = await r.json();
      setRows(j.results);
      if (!sel && j.results[0]) setSel(j.results[0].symbol);
    }
  }, [sel]);

  useEffect(() => {
    load();
    const i = setInterval(load, 20000);
    return () => clearInterval(i);
  }, [load]);

  useEffect(() => {
    if (!sel) return;
    fetch(`/api/scan?symbol=${encodeURIComponent(sel)}`)
      .then((r) => r.json())
      .then(setDetail);
  }, [sel]);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">Market Scanner</h1>
        <p className="text-xs text-slate-500">
          Analyse multi-actifs: tendance, momentum, volatilité, volume, structure, supports/résistances, RSI, MACD, ATR.
        </p>
      </div>

      <Card title="Classement par score d'opportunité">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-slate-500">
              <tr>
                {["Actif", "Prix", "24h", "Tendance", "RSI", "MACD", "ATR%", "Vol.", "Structure", "Setup", "Score"].map((h) => (
                  <th key={h} className="px-2 py-2 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="num">
              {rows.map((r) => (
                <tr
                  key={r.symbol}
                  onClick={() => setSel(r.symbol)}
                  className={`cursor-pointer border-t border-[#1c2230] hover:bg-slate-800/30 ${sel === r.symbol ? "bg-slate-800/40" : ""}`}
                >
                  <td className="px-2 py-2 font-medium text-slate-200">{r.symbol}</td>
                  <td className="px-2 py-2">{r.metrics.price}</td>
                  <td className={`px-2 py-2 ${r.metrics.change24h >= 0 ? "text-emerald-400" : "text-rose-400"}`}>{fmt(r.metrics.change24h)}%</td>
                  <td className="px-2 py-2">
                    <Badge tone={r.metrics.trend === "UP" ? "pos" : r.metrics.trend === "DOWN" ? "neg" : "neutral"}>{r.metrics.trend}</Badge>
                  </td>
                  <td className="px-2 py-2">{r.metrics.rsi}</td>
                  <td className={`px-2 py-2 ${r.metrics.macdHist >= 0 ? "text-emerald-400" : "text-rose-400"}`}>{r.metrics.macdHist}</td>
                  <td className="px-2 py-2">{r.metrics.atrPct}%</td>
                  <td className="px-2 py-2">{r.metrics.volumeRatio}x</td>
                  <td className="px-2 py-2 text-slate-400">{r.metrics.structure}</td>
                  <td className="px-2 py-2 text-slate-400">{r.strategy}</td>
                  <td className="px-2 py-2"><Badge tone={scoreTone(r.score)}>{r.score} · {r.grade}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Disclaimer text="Le score (0–100) mesure la qualité technique d'une configuration. Il ne constitue jamais une garantie de profit." />
      </Card>

      {detail && (
        <div className="grid gap-4 lg:grid-cols-3">
          <Card title={`${detail.scan.symbol} — ${detail.scan.name}`} className="lg:col-span-2">
            <PriceChart data={detail.candles} />
          </Card>
          <Card title="Lecture du marché">
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between"><span className="text-slate-500">Support</span><span className="num">{detail.scan.metrics.support}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Résistance</span><span className="num">{detail.scan.metrics.resistance}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">EMA20 / EMA50</span><span className="num">{detail.scan.metrics.ema20} / {detail.scan.metrics.ema50}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">SMA200</span><span className="num">{detail.scan.metrics.sma200}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Momentum 10 bougies</span><span className="num">{detail.scan.metrics.momentum}%</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Volatilité</span><span className="num">{detail.scan.metrics.volatility}%</span></div>
              <div className="flex gap-2 pt-1">
                {detail.scan.metrics.breakout && <Badge tone="info">Breakout</Badge>}
                {detail.scan.metrics.pullback && <Badge tone="info">Pullback</Badge>}
              </div>
            </div>
            <ul className="mt-4 space-y-1.5 text-[11px] leading-relaxed text-slate-400">
              {detail.scan.reasons.map((r, i) => (
                <li key={i}>• {r}</li>
              ))}
            </ul>
          </Card>
        </div>
      )}
    </div>
  );
}
