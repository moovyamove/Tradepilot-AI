import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import Shell from "@/components/Shell";
import { ensureUserEnvironment, requireUser } from "@/lib/auth";

export default async function AppLayout({ children }: { children: ReactNode }) {
  const user = await requireUser();
  if (!user) redirect("/login");
  await ensureUserEnvironment(user.id);
  return <Shell userName={`${user.name} · ${user.email}`}>{children}</Shell>;
}
