"use client";
import { useCallback, useEffect, useState } from "react";
import { Badge, Card, Disclaimer, fmt, money } from "@/components/ui";

type Trade = {
  id: number;
  symbol: string;
  direction: string;
  entry: number;
  exit: number;
  stopLoss: number;
  takeProfit: number;
  size: number;
  riskAmount: number;
  pnl: number;
  strategy: string;
  score: number;
  exitReason: string;
  closedAt: string;
  mode: string;
};

export default function History() {
  const [rows, setRows] = useState<Trade[]>([]);
  const [f, setF] = useState({ symbol: "ALL", direction: "ALL", strategy: "ALL", reason: "ALL" });

  const load = useCallback(async () => {
    const q = new URLSearchParams(f).toString();
    const r = await fetch(`/api/trades?${q}`);
    if (r.ok) setRows((await r.json()).trades);
  }, [f]);

  useEffect(() => {
    load();
  }, [load]);

  const symbols = Array.from(new Set(rows.map((r) => r.symbol)));
  const net = rows.reduce((s, t) => s + t.pnl, 0);

  const Select = ({ k, options }: { k: keyof typeof f; options: string[] }) => (
    <select
      value={f[k]}
      onChange={(e) => setF({ ...f, [k]: e.target.value })}
      className="rounded-md border border-slate-700 bg-slate-900/60 px-2 py-1.5 text-xs text-slate-200"
    >
      {["ALL", ...options].map((o) => (
        <option key={o} value={o}>{o}</option>
      ))}
    </select>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">Trade History</h1>
        <p className="text-xs text-slate-500">Toutes les opérations clôturées de votre environnement.</p>
      </div>
      <Card
        title={`${rows.length} trade(s)`}
        action={<span className={`num text-sm ${net >= 0 ? "text-emerald-400" : "text-rose-400"}`}>Net {money(net)}</span>}
      >
        <div className="mb-4 flex flex-wrap gap-2">
          <Select k="symbol" options={symbols} />
          <Select k="direction" options={["BUY", "SELL"]} />
          <Select k="strategy" options={["Trend Breakout", "Trend Pullback", "Momentum Continuation", "Mean Reversion"]} />
          <Select k="reason" options={["TAKE_PROFIT", "STOP_LOSS", "MANUAL"]} />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-slate-500">
              <tr>
                {["Date", "Actif", "Dir.", "Entry", "Exit", "SL", "TP", "Taille", "Risque", "P&L", "Stratégie", "Score", "Statut"].map((h) => (
                  <th key={h} className="px-2 py-2 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="num">
              {rows.map((t) => (
                <tr key={t.id} className="border-t border-[#1c2230]">
                  <td className="px-2 py-2 text-slate-400">{new Date(t.closedAt).toLocaleString("fr-FR")}</td>
                  <td className="px-2 py-2 text-slate-200">{t.symbol}</td>
                  <td className="px-2 py-2"><Badge tone={t.direction === "BUY" ? "pos" : "neg"}>{t.direction}</Badge></td>
                  <td className="px-2 py-2">{fmt(t.entry, 4)}</td>
                  <td className="px-2 py-2">{fmt(t.exit, 4)}</td>
                  <td className="px-2 py-2 text-rose-400">{fmt(t.stopLoss, 4)}</td>
                  <td className="px-2 py-2 text-emerald-400">{fmt(t.takeProfit, 4)}</td>
                  <td className="px-2 py-2">{t.size.toPrecision(4)}</td>
                  <td className="px-2 py-2">{money(t.riskAmount)}</td>
                  <td className={`px-2 py-2 ${t.pnl >= 0 ? "text-emerald-400" : "text-rose-400"}`}>{money(t.pnl)}</td>
                  <td className="px-2 py-2 text-slate-400">{t.strategy}</td>
                  <td className="px-2 py-2">{t.score}</td>
                  <td className="px-2 py-2">
                    <Badge tone={t.exitReason === "TAKE_PROFIT" ? "pos" : t.exitReason === "STOP_LOSS" ? "neg" : "neutral"}>
                      {t.exitReason}
                    </Badge>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <Disclaimer text="Historique de trades simulés (paper) ou exécutés en sandbox. Les performances passées ne préjugent pas des performances futures." />
      </Card>
    </div>
  );
}
