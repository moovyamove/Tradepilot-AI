"use client";
import { useCallback, useEffect, useState } from "react";
import { Badge, Button, Card, Disclaimer, fmt, money, scoreTone } from "@/components/ui";

type Pos = {
  id: number;
  symbol: string;
  direction: string;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  size: number;
  notional: number;
  riskAmount: number;
  strategy: string;
  score: number;
  mode: string;
  price: number;
  pnl: number;
  pnlPct: number;
  openedAt: string;
};

export default function Positions() {
  const [rows, setRows] = useState<Pos[]>([]);
  const [busy, setBusy] = useState<number | null>(null);

  const load = useCallback(async () => {
    const r = await fetch("/api/positions");
    if (r.ok) setRows((await r.json()).positions);
  }, []);

  useEffect(() => {
    load();
    const i = setInterval(load, 10000);
    return () => clearInterval(i);
  }, [load]);

  async function close(id: number) {
    setBusy(id);
    await fetch("/api/positions", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id }),
    });
    setBusy(null);
    load();
  }

  const total = rows.reduce((s, p) => s + p.pnl, 0);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">Positions ouvertes</h1>
        <p className="text-xs text-slate-500">
          Les stop-loss et take-profit sont surveillés en continu et exécutés automatiquement.
        </p>
      </div>
      <Card
        title={`${rows.length} position(s)`}
        action={<span className={`num text-sm ${total >= 0 ? "text-emerald-400" : "text-rose-400"}`}>P&L latent {money(total)}</span>}
      >
        {rows.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune position ouverte.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-slate-500">
                <tr>
                  {["Actif", "Dir.", "Mode", "Entrée", "Prix", "SL", "TP", "Taille", "Notionnel", "Risque", "Stratégie", "Score", "P&L", ""].map((h) => (
                    <th key={h} className="px-2 py-2 font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="num">
                {rows.map((p) => (
                  <tr key={p.id} className="border-t border-[#1c2230]">
                    <td className="px-2 py-2 text-slate-200">{p.symbol}</td>
                    <td className="px-2 py-2"><Badge tone={p.direction === "BUY" ? "pos" : "neg"}>{p.direction}</Badge></td>
                    <td className="px-2 py-2 text-slate-500">{p.mode}</td>
                    <td className="px-2 py-2">{p.entry}</td>
                    <td className="px-2 py-2">{p.price}</td>
                    <td className="px-2 py-2 text-rose-400">{p.stopLoss}</td>
                    <td className="px-2 py-2 text-emerald-400">{p.takeProfit}</td>
                    <td className="px-2 py-2">{p.size.toPrecision(4)}</td>
                    <td className="px-2 py-2">{money(p.notional)}</td>
                    <td className="px-2 py-2">{money(p.riskAmount)}</td>
                    <td className="px-2 py-2 text-slate-400">{p.strategy}</td>
                    <td className="px-2 py-2"><Badge tone={scoreTone(p.score)}>{p.score}</Badge></td>
                    <td className={`px-2 py-2 ${p.pnl >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                      {money(p.pnl)} <span className="text-slate-500">({fmt(p.pnlPct)}%)</span>
                    </td>
                    <td className="px-2 py-2">
                      <Button variant="ghost" onClick={() => close(p.id)} disabled={busy === p.id}>Fermer</Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <Disclaimer text="Le stop-loss ne peut jamais être contourné ni déplacé automatiquement contre la position." />
      </Card>
    </div>
  );
}
