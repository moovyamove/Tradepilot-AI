"use client";
import { useCallback, useEffect, useState } from "react";
import { Badge, Button, Card, Disclaimer } from "@/components/ui";

type Acc = { mode: string; autoTrading: boolean; killSwitch: boolean; killReason: string | null };
type Notif = { id: number; level: string; title: string; body: string; createdAt: string; readAt: string | null };
type Log = { id: number; action: string; detail: unknown; createdAt: string };

export default function Settings() {
  const [acc, setAcc] = useState<Acc | null>(null);
  const [notifs, setNotifs] = useState<Notif[]>([]);
  const [logs, setLogs] = useState<Log[]>([]);
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    const [p, n, a] = await Promise.all([fetch("/api/portfolio"), fetch("/api/notifications"), fetch("/api/audit")]);
    if (p.ok) setAcc((await p.json()).account);
    if (n.ok) setNotifs((await n.json()).notifications);
    if (a.ok) setLogs((await a.json()).logs);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function act(body: Record<string, unknown>) {
    const r = await fetch("/api/account", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const j = await r.json();
    setMsg(r.ok ? "Mise à jour effectuée." : j.error);
    load();
  }

  async function goLive() {
    const ok = window.confirm(
      "ACTIVATION DU MODE LIVE\n\nDes ordres pourront être transmis à votre broker via l'adaptateur configuré. Toutes les exécutions resteront soumises au Risk Engine.\n\nConfirmez-vous explicitement l'activation ?",
    );
    if (!ok) return;
    act({ action: "setMode", mode: "LIVE", confirm: true });
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">Settings</h1>
        <p className="text-xs text-slate-500">Mode d&apos;exécution, auto-trading, alertes et journal d&apos;audit.</p>
      </div>

      <Card title="Mode d'exécution">
        <div className="flex flex-wrap items-center gap-3">
          <Badge tone={acc?.mode === "LIVE" ? "warn" : "info"}>{acc?.mode ?? "—"}</Badge>
          <Button variant="ghost" onClick={() => act({ action: "setMode", mode: "PAPER" })}>Passer en PAPER</Button>
          <Button variant="danger" onClick={goLive} disabled={acc?.mode === "LIVE"}>Activer LIVE (confirmation requise)</Button>
        </div>
        <Disclaimer text="Le mode LIVE est désactivé par défaut. En passant d'un mode à l'autre, l'auto-trading est systématiquement remis à OFF." />
      </Card>

      <Card title="Auto Trading">
        <div className="flex flex-wrap items-center gap-3">
          <Badge tone={acc?.autoTrading ? "pos" : "neutral"}>AUTO {acc?.autoTrading ? "ON" : "OFF"}</Badge>
          <Button variant={acc?.autoTrading ? "ghost" : "success"} onClick={() => act({ action: "setAutoTrading", enabled: !acc?.autoTrading })}>
            {acc?.autoTrading ? "Désactiver" : "Activer"}
          </Button>
          <Button variant="ghost" onClick={() => act({ action: "resetPaper" })}>Réinitialiser le compte papier</Button>
        </div>
        <Disclaimer text="Lorsque l'auto-trading est OFF, aucun ordre n'est envoyé. Lorsqu'il est ON, chaque ordre passe obligatoirement par le Risk Engine." />
      </Card>

      <Card title="État du système">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <Badge tone={acc?.killSwitch ? "neg" : "pos"}>{acc?.killSwitch ? "HALTED" : "OPÉRATIONNEL"}</Badge>
          {acc?.killReason && <span className="text-rose-300">{acc.killReason}</span>}
          <Button variant={acc?.killSwitch ? "ghost" : "danger"} onClick={() => act({ action: "killSwitch", enabled: !acc?.killSwitch })}>
            {acc?.killSwitch ? "Réarmer le système" : "EMERGENCY STOP"}
          </Button>
          {msg && <span className="text-sky-400">{msg}</span>}
        </div>
      </Card>

      <Card
        title="Alertes"
        action={<Button variant="ghost" onClick={async () => { await fetch("/api/notifications", { method: "POST" }); load(); }}>Tout marquer comme lu</Button>}
      >
        <div className="max-h-80 space-y-2 overflow-y-auto">
          {notifs.map((n) => (
            <div key={n.id} className="rounded-lg border border-slate-800 p-3 text-xs">
              <div className="flex items-center justify-between gap-2">
                <span className="text-slate-200">{n.title}</span>
                <Badge tone={n.level === "danger" ? "neg" : n.level === "warning" ? "warn" : n.level === "success" ? "pos" : "info"}>{n.level}</Badge>
              </div>
              {n.body && <div className="mt-1 text-slate-500">{n.body}</div>}
              <div className="mt-1 text-[10px] text-slate-600">{new Date(n.createdAt).toLocaleString("fr-FR")}</div>
            </div>
          ))}
          {notifs.length === 0 && <p className="text-sm text-slate-500">Aucune alerte.</p>}
        </div>
      </Card>

      <Card title="Audit logs">
        <div className="max-h-80 overflow-y-auto">
          <table className="w-full text-left text-[11px]">
            <tbody>
              {logs.map((l) => (
                <tr key={l.id} className="border-t border-[#1c2230]">
                  <td className="px-2 py-1.5 text-slate-500">{new Date(l.createdAt).toLocaleString("fr-FR")}</td>
                  <td className="px-2 py-1.5 text-slate-200">{l.action}</td>
                  <td className="px-2 py-1.5 text-slate-500">{JSON.stringify(l.detail).slice(0, 90)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
