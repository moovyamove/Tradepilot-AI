"use client";
import { useState } from "react";
import { Badge, Button, Card, Disclaimer, fmt, money } from "@/components/ui";
import { SimpleCurve } from "@/components/Charts";

const SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT", "XRP/USDT", "EUR/USD", "GBP/USD", "XAU/USD", "AAPL", "NVDA", "TSLA"];
const STRATS = ["ALL", "Trend Breakout", "Trend Pullback", "Momentum Continuation", "Mean Reversion"];

type Result = {
  symbol: string;
  strategy: string;
  returnPct: number;
  endingBalance: number;
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  profitFactor: number;
  avgWin: number;
  avgLoss: number;
  expectancy: number;
  maxDrawdownPct: number;
  sharpe: number;
  equityCurve: { i: number; equity: number }[];
  tradeList: { i: number; direction: string; entry: number; exit: number; pnl: number; reason: string; score: number }[];
  disclaimer: string;
};

export default function Backtesting() {
  const [symbol, setSymbol] = useState(SYMBOLS[0]);
  const [bars, setBars] = useState(1000);
  const [strategy, setStrategy] = useState("ALL");
  const [balance, setBalance] = useState(10000);
  const [res, setRes] = useState<Result | null>(null);
  const [busy, setBusy] = useState(false);

  async function run() {
    setBusy(true);
    const r = await fetch("/api/backtest", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ symbol, bars, strategy, startingBalance: balance }),
    });
    const j = await r.json();
    setRes(j.result ?? null);
    setBusy(false);
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">Strategy Lab — Backtesting</h1>
        <p className="text-xs text-slate-500">Test d&apos;une stratégie sur données historiques, avec vos paramètres de risque actuels.</p>
      </div>

      <Card title="Configuration">
        <div className="grid gap-3 sm:grid-cols-4">
          <label className="text-xs text-slate-400">
            Actif
            <select value={symbol} onChange={(e) => setSymbol(e.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-900/60 px-2 py-2 text-sm text-slate-100">
              {SYMBOLS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </label>
          <label className="text-xs text-slate-400">
            Stratégie
            <select value={strategy} onChange={(e) => setStrategy(e.target.value)} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-900/60 px-2 py-2 text-sm text-slate-100">
              {STRATS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </label>
          <label className="text-xs text-slate-400">
            Bougies (15m)
            <input type="number" min={200} max={3000} value={bars} onChange={(e) => setBars(Number(e.target.value))} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-900/60 px-2 py-2 text-sm text-slate-100" />
          </label>
          <label className="text-xs text-slate-400">
            Capital initial
            <input type="number" min={100} value={balance} onChange={(e) => setBalance(Number(e.target.value))} className="mt-1 w-full rounded-md border border-slate-700 bg-slate-900/60 px-2 py-2 text-sm text-slate-100" />
          </label>
        </div>
        <div className="mt-4">
          <Button onClick={run} disabled={busy}>{busy ? "Calcul en cours…" : "Lancer le backtest"}</Button>
        </div>
      </Card>

      {res && (
        <>
          <div className="grid gap-3 sm:grid-cols-3 xl:grid-cols-5">
            <Metric label="Rendement" value={`${fmt(res.returnPct)}%`} tone={res.returnPct >= 0 ? "pos" : "neg"} />
            <Metric label="Capital final" value={money(res.endingBalance)} />
            <Metric label="Profit factor" value={`${res.profitFactor}`} />
            <Metric label="Win rate" value={`${res.winRate}%`} />
            <Metric label="Trades" value={`${res.trades}`} />
            <Metric label="Gain moyen" value={money(res.avgWin)} tone="pos" />
            <Metric label="Perte moyenne" value={money(res.avgLoss)} tone="neg" />
            <Metric label="Expectancy" value={money(res.expectancy)} />
            <Metric label="Drawdown max" value={`${res.maxDrawdownPct}%`} tone="warn" />
            <Metric label="Sharpe" value={`${res.sharpe}`} />
          </div>
          <Card title={`Courbe d'equity — ${res.symbol} (${res.strategy})`}>
            <SimpleCurve data={res.equityCurve} />
            <Disclaimer text={res.disclaimer} />
          </Card>
          <Card title="Derniers trades simulés">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="text-slate-500">
                  <tr>{["Bougie", "Dir.", "Entry", "Exit", "Score", "Sortie", "P&L"].map((h) => <th key={h} className="px-2 py-2 font-medium">{h}</th>)}</tr>
                </thead>
                <tbody className="num">
                  {res.tradeList.map((t, i) => (
                    <tr key={i} className="border-t border-[#1c2230]">
                      <td className="px-2 py-2 text-slate-400">{t.i}</td>
                      <td className="px-2 py-2"><Badge tone={t.direction === "BUY" ? "pos" : "neg"}>{t.direction}</Badge></td>
                      <td className="px-2 py-2">{fmt(t.entry, 4)}</td>
                      <td className="px-2 py-2">{fmt(t.exit, 4)}</td>
                      <td className="px-2 py-2">{t.score}</td>
                      <td className="px-2 py-2 text-slate-400">{t.reason}</td>
                      <td className={`px-2 py-2 ${t.pnl >= 0 ? "text-emerald-400" : "text-rose-400"}`}>{money(t.pnl)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </>
      )}
    </div>
  );
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: "pos" | "neg" | "warn" }) {
  const c = tone === "pos" ? "text-emerald-400" : tone === "neg" ? "text-rose-400" : tone === "warn" ? "text-amber-400" : "text-slate-100";
  return (
    <div className="card p-3">
      <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
      <div className={`num mt-1 text-lg font-semibold ${c}`}>{value}</div>
    </div>
  );
}
