"use client";
import { useEffect, useState } from "react";
import { Badge, Card, Disclaimer } from "@/components/ui";

const STRATEGIES = [
  {
    name: "Trend Breakout",
    desc: "Cassure d'un extrême de 60 bougies dans le sens de la tendance (EMA20/EMA50/SMA200), confirmée par le volume.",
    filters: ["Tendance alignée", "Volume > 1.2x moyenne", "ATR dans une plage saine"],
    exit: "Stop basé sur 1.6 ATR ou la structure, take-profit à 2–3R.",
  },
  {
    name: "Trend Pullback",
    desc: "Repli sur l'EMA20 dans une tendance établie, reprise confirmée par le MACD et le RSI.",
    filters: ["Prix entre EMA20 et EMA50", "RSI en zone de continuation", "MACD aligné"],
    exit: "Stop sous/au-dessus du dernier swing, take-profit 2–2.5R.",
  },
  {
    name: "Momentum Continuation",
    desc: "Poursuite d'une impulsion directionnelle avec momentum positif et participation du volume.",
    filters: ["Momentum 10 bougies significatif", "MACD histogramme dans le sens", "Pas de zone extrême du RSI"],
    exit: "Stop ATR, take-profit 2R minimum.",
  },
  {
    name: "Mean Reversion",
    desc: "Marché en range: retour vers la moyenne depuis un bord de range. Score volontairement pénalisé.",
    filters: ["Structure en range", "RSI non extrême", "Volatilité modérée"],
    exit: "Stop hors du range, take-profit sur le milieu/bord opposé.",
  },
];

export default function Strategies() {
  const [cfg, setCfg] = useState<Record<string, number> | null>(null);
  useEffect(() => {
    fetch("/api/risk").then((r) => r.json()).then((j) => setCfg(j.risk));
  }, []);
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">Strategies</h1>
        <p className="text-xs text-slate-500">
          Le moteur de stratégie propose; le Risk Engine dispose. Aucune stratégie ne peut outrepasser les limites de risque.
        </p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        {STRATEGIES.map((s) => (
          <Card key={s.name} title={s.name} action={<Badge tone="info">Active</Badge>}>
            <p className="text-xs leading-relaxed text-slate-400">{s.desc}</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {s.filters.map((f) => (
                <span key={f} className="rounded-md border border-slate-700 bg-slate-800/40 px-2 py-1 text-[11px] text-slate-300">{f}</span>
              ))}
            </div>
            <p className="mt-3 text-[11px] text-slate-500">Sortie: {s.exit}</p>
          </Card>
        ))}
      </div>
      <Card title="Filtres globaux appliqués par le Risk Engine">
        {cfg && (
          <div className="grid gap-2 text-xs sm:grid-cols-3">
            <span className="text-slate-400">Score minimum: <b className="text-slate-100">{cfg.minScore}</b></span>
            <span className="text-slate-400">R:R minimum: <b className="text-slate-100">1:{cfg.minRiskReward}</b></span>
            <span className="text-slate-400">Risque par trade: <b className="text-slate-100">{cfg.riskPerTradePct}%</b></span>
          </div>
        )}
        <Disclaimer text="Aucun martingale, aucune augmentation automatique du risque après une perte, aucun contournement du stop-loss." />
      </Card>
    </div>
  );
}
