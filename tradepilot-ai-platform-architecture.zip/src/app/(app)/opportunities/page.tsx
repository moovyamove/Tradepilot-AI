"use client";
import { useCallback, useEffect, useState } from "react";
import { Badge, Button, Card, Disclaimer, fmt, scoreTone } from "@/components/ui";

type Check = { name: string; passed: boolean; critical: boolean; detail: string };
type Opp = {
  symbol: string;
  direction: "BUY" | "SELL";
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskReward: number;
  score: number;
  strategy: string;
  reasons: string[];
  decision: { approved: boolean; size: number; notional: number; riskAmount: number; checks: Check[]; rejectionReasons: string[] };
};

const PIPELINE = [
  "Market Scanner",
  "Strategy Engine",
  "Opportunity Score",
  "Risk Engine",
  "Exposure Check",
  "Daily Loss Check",
  "Drawdown Check",
  "Position Limit Check",
  "API / Broker Check",
  "Execution",
];

export default function Opportunities() {
  const [opps, setOpps] = useState<Opp[]>([]);
  const [open, setOpen] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [result, setResult] = useState<string | null>(null);
  const [ai, setAi] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    const r = await fetch("/api/opportunities");
    if (r.ok) setOpps((await r.json()).opportunities);
  }, []);

  useEffect(() => {
    load();
    const i = setInterval(load, 20000);
    return () => clearInterval(i);
  }, [load]);

  async function execute(symbol: string, dryRun: boolean) {
    setBusy(symbol);
    const r = await fetch("/api/trade/execute", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ symbol, dryRun }),
    });
    const j = await r.json();
    setResult(
      j.executed
        ? `✅ Trade exécuté sur ${symbol} — taille ${j.size}, risque $${j.riskAmount}.`
        : j.approved
          ? `✔️ Simulation: trade APPROUVÉ par le Risk Engine (taille ${j.size}, risque $${j.riskAmount}).`
          : `⛔ Trade REFUSÉ — ${(j.rejectionReasons ?? []).join(" | ")}`,
    );
    setBusy(null);
    load();
  }

  async function explain(symbol: string) {
    const r = await fetch("/api/ai", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ question: "pourquoi cette opportunité ?", symbol }),
    });
    const j = await r.json();
    setAi((a) => ({ ...a, [symbol]: j.answer }));
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">Opportunity Engine</h1>
        <p className="text-xs text-slate-500">
          Chaque plan de trade passe par le pipeline de validation complet avant toute exécution.
        </p>
      </div>

      <Card title="Trade Validation Pipeline">
        <div className="flex flex-wrap gap-2 text-[11px]">
          {PIPELINE.map((p, i) => (
            <span key={p} className="rounded-md border border-slate-700 bg-slate-800/40 px-2 py-1 text-slate-300">
              {i + 1}. {p}
            </span>
          ))}
        </div>
        <Disclaimer text="Si une seule condition critique échoue, le trade est refusé et la raison est affichée." />
      </Card>

      {result && (
        <div className="card border-sky-500/30 bg-sky-500/5 p-3 text-xs text-sky-200">{result}</div>
      )}

      <div className="grid gap-4 lg:grid-cols-2">
        {opps.map((o) => (
          <Card key={o.symbol}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-base font-semibold text-white">{o.symbol}</span>
                  <Badge tone={o.direction === "BUY" ? "pos" : "neg"}>{o.direction}</Badge>
                  <Badge tone={scoreTone(o.score)}>{o.score}/100</Badge>
                </div>
                <div className="mt-1 text-[11px] text-slate-500">Stratégie: {o.strategy}</div>
              </div>
              <Badge tone={o.decision.approved ? "pos" : "neg"}>
                {o.decision.approved ? "VALIDÉ RISK ENGINE" : "REFUSÉ"}
              </Badge>
            </div>

            <div className="num mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-xs sm:grid-cols-3">
              <KV k="Entry" v={`${o.entry}`} />
              <KV k="Stop Loss" v={`${o.stopLoss}`} tone="neg" />
              <KV k="Take Profit" v={`${o.takeProfit}`} tone="pos" />
              <KV k="Risk / Reward" v={`1:${fmt(o.riskReward)}`} />
              <KV k="Taille calculée" v={`${o.decision.size}`} />
              <KV k="Risque" v={`$${fmt(o.decision.riskAmount)}`} />
            </div>

            <ul className="mt-3 space-y-1 text-[11px] leading-relaxed text-slate-400">
              {o.reasons.slice(0, 4).map((r, i) => (
                <li key={i}>• {r}</li>
              ))}
            </ul>

            {!o.decision.approved && (
              <div className="mt-3 rounded-md border border-rose-500/30 bg-rose-500/5 p-2 text-[11px] text-rose-300">
                {o.decision.rejectionReasons.map((r, i) => (
                  <div key={i}>⛔ {r}</div>
                ))}
              </div>
            )}

            <div className="mt-4 flex flex-wrap gap-2">
              <Button variant="ghost" onClick={() => setOpen(open === o.symbol ? null : o.symbol)}>
                {open === o.symbol ? "Masquer" : "Voir les 10 contrôles"}
              </Button>
              <Button variant="ghost" onClick={() => explain(o.symbol)}>Expliquer (IA)</Button>
              <Button variant="ghost" onClick={() => execute(o.symbol, true)} disabled={busy === o.symbol}>
                Simuler la validation
              </Button>
              <Button
                variant="success"
                onClick={() => execute(o.symbol, false)}
                disabled={busy === o.symbol || !o.decision.approved}
              >
                Exécuter
              </Button>
            </div>

            {open === o.symbol && (
              <div className="mt-3 space-y-1 text-[11px]">
                {o.decision.checks.map((c) => (
                  <div key={c.name} className="flex gap-2 border-b border-[#161c27] py-1">
                    <span className={c.passed ? "text-emerald-400" : "text-rose-400"}>{c.passed ? "✓" : "✗"}</span>
                    <span className="w-44 shrink-0 text-slate-300">{c.name}</span>
                    <span className="text-slate-500">{c.detail}</span>
                  </div>
                ))}
              </div>
            )}

            {ai[o.symbol] && (
              <pre className="mt-3 whitespace-pre-wrap rounded-md border border-slate-700 bg-slate-900/40 p-3 text-[11px] leading-relaxed text-slate-300">
                {ai[o.symbol]}
              </pre>
            )}
          </Card>
        ))}
      </div>
      {opps.length === 0 && <p className="text-sm text-slate-500">Aucune opportunité exploitable actuellement.</p>}
      <Disclaimer text="Aucune opportunité ne garantit un profit. Le dimensionnement est calculé à partir du capital, du risque autorisé et de la distance du stop-loss." />
    </div>
  );
}

function KV({ k, v, tone }: { k: string; v: string; tone?: "pos" | "neg" }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-slate-500">{k}</div>
      <div className={tone === "pos" ? "text-emerald-400" : tone === "neg" ? "text-rose-400" : "text-slate-200"}>{v}</div>
    </div>
  );
}
