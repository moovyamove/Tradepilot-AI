"use client";
import { useEffect, useState } from "react";
import { Button, Card, Disclaimer } from "@/components/ui";

type Risk = {
  riskPerTradePct: number;
  maxDailyLossPct: number;
  maxDrawdownPct: number;
  maxOpenPositions: number;
  maxExposurePct: number;
  maxPositionSizePct: number;
  maxConsecutiveLosses: number;
  minRiskReward: number;
  minScore: number;
};

const FIELDS: { k: keyof Risk; label: string; hint: string; step: number }[] = [
  { k: "riskPerTradePct", label: "Risque maximal par trade (%)", hint: "Défaut 0,5 %", step: 0.05 },
  { k: "maxDailyLossPct", label: "Perte maximale quotidienne (%)", hint: "Défaut 2 %", step: 0.1 },
  { k: "maxDrawdownPct", label: "Drawdown maximal (%)", hint: "Défaut 10 %", step: 0.5 },
  { k: "maxOpenPositions", label: "Nombre maximal de positions", hint: "Défaut 3", step: 1 },
  { k: "maxExposurePct", label: "Exposition maximale (% equity)", hint: "Notionnel cumulé", step: 1 },
  { k: "maxPositionSizePct", label: "Taille maximale d'une position (%)", hint: "Plafond de notionnel", step: 1 },
  { k: "maxConsecutiveLosses", label: "Pertes consécutives maximales", hint: "Arrêt automatique au-delà", step: 1 },
  { k: "minRiskReward", label: "Ratio risque/rendement minimum", hint: "Défaut 1:2", step: 0.1 },
  { k: "minScore", label: "Score minimum d'opportunité", hint: "Défaut 65/100", step: 1 },
];

export default function RiskPage() {
  const [r, setR] = useState<Risk | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/risk").then((x) => x.json()).then((j) => setR(j.risk));
  }, []);

  async function save() {
    if (!r) return;
    setBusy(true);
    const res = await fetch("/api/risk", {
      method: "PUT",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(r),
    });
    const j = await res.json();
    setMsg(res.ok ? "Paramètres de risque mis à jour." : j.error);
    setBusy(false);
  }

  if (!r) return <div className="text-sm text-slate-500">Chargement…</div>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold text-white">Risk Management</h1>
        <p className="text-xs text-slate-500">
          Moteur de risque indépendant: il peut refuser toute opération, y compris celles proposées par l&apos;IA.
        </p>
      </div>

      <Card title="Limites utilisateur">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {FIELDS.map((f) => (
            <label key={f.k} className="text-xs text-slate-400">
              {f.label}
              <input
                type="number"
                step={f.step}
                value={r[f.k]}
                onChange={(e) => setR({ ...r, [f.k]: Number(e.target.value) })}
                className="num mt-1 w-full rounded-md border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100"
              />
              <span className="mt-1 block text-[10px] text-slate-600">{f.hint}</span>
            </label>
          ))}
        </div>
        <div className="mt-5 flex items-center gap-3">
          <Button onClick={save} disabled={busy}>Enregistrer</Button>
          {msg && <span className="text-xs text-sky-400">{msg}</span>}
        </div>
      </Card>

      <Card title="Calcul de la taille de position">
        <pre className="overflow-x-auto rounded-lg border border-slate-800 bg-slate-900/50 p-4 text-[11px] leading-relaxed text-slate-300">
{`risque_autorisé = equity × risquePar Trade%
distance_stop   = |entrée − stop_loss|
taille          = risque_autorisé / distance_stop
notionnel       = taille × entrée   (plafonné par maxPositionSize%)`}
        </pre>
        <Disclaimer text="La taille n'est jamais calculée uniquement à partir du capital: la distance du stop-loss est obligatoire. Aucune augmentation automatique du risque après une perte (pas de martingale)." />
      </Card>

      <Card title="Arrêts automatiques">
        <ul className="space-y-1.5 text-xs text-slate-400">
          <li>• Perte quotidienne maximale atteinte → arrêt du moteur et blocage des nouveaux ordres.</li>
          <li>• Drawdown maximal atteint → arrêt immédiat.</li>
          <li>• Pertes consécutives au-delà de la limite → arrêt immédiat.</li>
          <li>• Comportement API anormal, erreurs répétées ou données de marché invalides → refus d&apos;exécution.</li>
          <li>• Perte de connexion broker → aucun ordre envoyé.</li>
        </ul>
      </Card>
    </div>
  );
}
