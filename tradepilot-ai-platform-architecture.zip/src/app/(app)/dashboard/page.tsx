"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { Badge, Button, Card, Disclaimer, Stat, fmt, money, scoreTone } from "@/components/ui";
import { DrawdownChart, EquityChart, PnlBars } from "@/components/Charts";

type Stats = {
  account: { mode: string; autoTrading: boolean; killSwitch: boolean; consecutiveLosses: number };
  risk: Record<string, number>;
  metrics: Record<string, number>;
  openPositions: {
    id: number;
    symbol: string;
    direction: string;
    entry: number;
    stopLoss: number;
    takeProfit: number;
    size: number;
    price: number;
    pnl: number;
    score: number;
    strategy: string;
  }[];
  curve: { t: string; equity: number; drawdown: number }[];
  recentTrades: { id: number; symbol: string; direction: string; pnl: number; exitReason: string; closedAt: string }[];
};

export default function Dashboard() {
  const [s, setS] = useState<Stats | null>(null);
  const [ai, setAi] = useState<string>("");
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const r = await fetch("/api/portfolio");
    if (r.ok) setS(await r.json());
  }, []);

  useEffect(() => {
    load();
    const i = setInterval(load, 15000);
    return () => clearInterval(i);
  }, [load]);

  async function askAi() {
    setBusy(true);
    const r = await fetch("/api/ai", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ question: "résumé de performance" }),
    });
    setAi((await r.json()).answer ?? "");
    setBusy(false);
  }

  if (!s) return <div className="text-sm text-slate-500">Chargement du portefeuille…</div>;
  const m = s.metrics;
  const pnlByTrade = s.recentTrades
    .slice(0, 12)
    .reverse()
    .map((t, i) => ({ label: `#${i + 1}`, pnl: Number(t.pnl.toFixed(2)) }));

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold text-white">Dashboard</h1>
          <p className="text-xs text-slate-500">
            Environnement {s.account.mode} · Auto trading {s.account.autoTrading ? "ON" : "OFF"}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/opportunities">
            <Button variant="primary">Voir les opportunités</Button>
          </Link>
          <Link href="/risk">
            <Button variant="ghost">Paramètres de risque</Button>
          </Link>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Stat label="Capital disponible" value={money(m.balance)} sub="Cash non engagé" />
        <Stat label="Equity" value={money(m.equity)} sub="Capital + P&L latent" />
        <Stat label="P&L du jour" value={money(m.dayPnl)} tone={m.dayPnl >= 0 ? "pos" : "neg"} sub={`Limite quotidienne ${s.risk.maxDailyLossPct}%`} />
        <Stat label="P&L total" value={money(m.totalPnl)} tone={m.totalPnl >= 0 ? "pos" : "neg"} sub={`Réalisé ${money(m.realizedPnl)}`} />
        <Stat label="Drawdown courant" value={`${fmt(m.drawdownPct)}%`} tone={m.drawdownPct > s.risk.maxDrawdownPct * 0.6 ? "warn" : "neutral"} sub={`Max autorisé ${s.risk.maxDrawdownPct}%`} />
        <Stat label="Taux de réussite" value={`${fmt(m.winRate, 1)}%`} sub={`${m.wins} gagnants / ${m.losses} perdants`} />
        <Stat label="Trades clôturés" value={`${m.trades}`} sub={`Profit factor ${m.profitFactor}`} />
        <Stat label="Exposition" value={`${fmt(m.exposurePct)}%`} tone={m.exposurePct > s.risk.maxExposurePct * 0.8 ? "warn" : "neutral"} sub={`${money(m.exposure)} / max ${s.risk.maxExposurePct}%`} />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card title="Évolution du capital" className="lg:col-span-2">
          <EquityChart data={s.curve} />
        </Card>
        <Card title="Risque en cours">
          <div className="space-y-3 text-sm">
            <Row label="Risque engagé" value={`${money(m.riskInMarket)} (${fmt(m.riskInMarketPct)}%)`} />
            <Row label="Perte du jour utilisée" value={`${fmt(m.dailyLossUsedPct)}% / ${s.risk.maxDailyLossPct}%`} />
            <Row label="Positions ouvertes" value={`${s.openPositions.length} / ${s.risk.maxOpenPositions}`} />
            <Row label="Pertes consécutives" value={`${s.account.consecutiveLosses} / ${s.risk.maxConsecutiveLosses}`} />
            <Row label="Risque par trade" value={`${s.risk.riskPerTradePct}% du capital`} />
            <Row label="R:R minimum" value={`1:${s.risk.minRiskReward}`} />
          </div>
          <Disclaimer text="Le Risk Engine est indépendant du moteur de stratégie et peut refuser toute opération." />
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card title="Drawdown (%)">
          <DrawdownChart data={s.curve} />
        </Card>
        <Card title="P&L des derniers trades">
          <PnlBars data={pnlByTrade} />
        </Card>
      </div>

      <Card title="Positions ouvertes" action={<Link href="/positions" className="text-xs text-sky-400">Gérer</Link>}>
        {s.openPositions.length === 0 ? (
          <p className="text-sm text-slate-500">Aucune position ouverte.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-slate-500">
                <tr>
                  {["Actif", "Direction", "Entrée", "Prix", "SL", "TP", "Taille", "Score", "P&L"].map((h) => (
                    <th key={h} className="px-2 py-2 font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="num">
                {s.openPositions.map((p) => (
                  <tr key={p.id} className="border-t border-[#1c2230]">
                    <td className="px-2 py-2 text-slate-200">{p.symbol}</td>
                    <td className="px-2 py-2"><Badge tone={p.direction === "BUY" ? "pos" : "neg"}>{p.direction}</Badge></td>
                    <td className="px-2 py-2">{p.entry}</td>
                    <td className="px-2 py-2">{p.price}</td>
                    <td className="px-2 py-2 text-rose-400">{p.stopLoss}</td>
                    <td className="px-2 py-2 text-emerald-400">{p.takeProfit}</td>
                    <td className="px-2 py-2">{p.size.toPrecision(4)}</td>
                    <td className="px-2 py-2"><Badge tone={scoreTone(p.score)}>{p.score}</Badge></td>
                    <td className={`px-2 py-2 ${p.pnl >= 0 ? "text-emerald-400" : "text-rose-400"}`}>{money(p.pnl)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Card title="AI Assistant — explications" action={<Button variant="ghost" onClick={askAi} disabled={busy}>Résumer ma performance</Button>}>
        <pre className="whitespace-pre-wrap text-xs leading-relaxed text-slate-300">
          {ai || "Demandez une explication: performance, risque, refus de trade, fermeture de position."}
        </pre>
      </Card>

      <Disclaimer text="Les scores, signaux et statistiques affichés sont des outils d'aide à la décision. Ils ne constituent pas un conseil en investissement ni une garantie de profit." />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between border-b border-[#161c27] pb-2">
      <span className="text-xs text-slate-500">{label}</span>
      <span className="num text-slate-200">{value}</span>
    </div>
  );
}
