"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

type Mode = "login" | "register" | "forgot";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<Mode>("login");
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    setMsg(null);
    try {
      if (mode === "forgot") {
        const r = await fetch("/api/auth/password", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ action: "forgot", email }),
        });
        const j = await r.json();
        setMsg(
          j.resetToken
            ? `Lien de réinitialisation généré (sandbox) — token: ${j.resetToken}`
            : "Si un compte existe, un email de réinitialisation a été envoyé.",
        );
      } else {
        const url = mode === "login" ? "/api/auth/login" : "/api/auth/register";
        const r = await fetch(url, {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ email, password, name }),
        });
        const j = await r.json();
        if (!r.ok) throw new Error(j.error ?? "Erreur");
        router.push("/dashboard");
        router.refresh();
      }
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Erreur inconnue");
    } finally {
      setBusy(false);
    }
  }

  async function demo() {
    setBusy(true);
    await fetch("/api/auth/demo", { method: "POST" });
    router.push("/dashboard");
    router.refresh();
  }

  return (
    <main className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="mb-6 flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-sky-500 to-indigo-600 font-bold text-white">
            TP
          </div>
          <div>
            <div className="font-semibold text-white">TradePilot AI</div>
            <div className="text-[11px] uppercase tracking-widest text-slate-500">Secure access</div>
          </div>
        </div>
        <div className="card p-6">
          <div className="mb-5 flex gap-2 text-xs">
            {(["login", "register", "forgot"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`rounded-md px-3 py-1.5 ${mode === m ? "bg-sky-500/15 text-sky-300" : "text-slate-400 hover:text-slate-200"}`}
              >
                {m === "login" ? "Connexion" : m === "register" ? "Inscription" : "Mot de passe oublié"}
              </button>
            ))}
          </div>
          <form onSubmit={submit} className="space-y-3">
            {mode === "register" && (
              <input
                className="w-full rounded-lg border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-sky-500"
                placeholder="Nom"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
            )}
            <input
              type="email"
              required
              className="w-full rounded-lg border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-sky-500"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            {mode !== "forgot" && (
              <input
                type="password"
                required
                minLength={8}
                className="w-full rounded-lg border border-slate-700 bg-slate-900/60 px-3 py-2 text-sm text-slate-100 outline-none focus:border-sky-500"
                placeholder="Mot de passe (8 caractères min.)"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            )}
            {err && <div className="rounded-md border border-rose-500/30 bg-rose-500/10 p-2 text-xs text-rose-300">{err}</div>}
            {msg && <div className="rounded-md border border-sky-500/30 bg-sky-500/10 p-2 text-xs text-sky-300 break-all">{msg}</div>}
            <button
              disabled={busy}
              className="w-full rounded-lg bg-sky-600 py-2.5 text-sm font-medium text-white hover:bg-sky-500 disabled:opacity-50"
            >
              {mode === "login" ? "Se connecter" : mode === "register" ? "Créer mon compte" : "Envoyer le lien"}
            </button>
          </form>
          <div className="my-4 flex items-center gap-3 text-[11px] text-slate-600">
            <div className="h-px flex-1 bg-slate-800" /> ou <div className="h-px flex-1 bg-slate-800" />
          </div>
          <a
            href="/api/auth/google"
            className="block w-full rounded-lg border border-slate-700 py-2.5 text-center text-sm text-slate-200 hover:bg-slate-800"
          >
            Continuer avec Google
          </a>
          <button
            onClick={demo}
            disabled={busy}
            className="mt-2 w-full rounded-lg border border-slate-700 py-2.5 text-sm text-slate-300 hover:bg-slate-800"
          >
            Explorer le compte démo (paper trading)
          </button>
        </div>
        <p className="mt-4 text-[11px] leading-relaxed text-slate-500">
          Le mode LIVE est désactivé par défaut. Aucune clé API n&apos;est stockée en clair ni exposée au frontend.
          Le trading comporte un risque de perte en capital.
        </p>
      </div>
    </main>
  );
}
