import {
  pgTable,
  serial,
  text,
  timestamp,
  doublePrecision,
  integer,
  boolean,
  jsonb,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull().default(""),
  passwordHash: text("password_hash").notNull(),
  emailVerified: boolean("email_verified").notNull().default(false),
  verifyToken: text("verify_token"),
  resetToken: text("reset_token"),
  provider: text("provider").notNull().default("password"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  mode: text("mode").notNull().default("PAPER"), // PAPER | LIVE
  autoTrading: boolean("auto_trading").notNull().default(false),
  killSwitch: boolean("kill_switch").notNull().default(false),
  killReason: text("kill_reason"),
  startingBalance: doublePrecision("starting_balance").notNull().default(10000),
  balance: doublePrecision("balance").notNull().default(10000),
  equityPeak: doublePrecision("equity_peak").notNull().default(10000),
  dayAnchorEquity: doublePrecision("day_anchor_equity").notNull().default(10000),
  dayAnchorDate: text("day_anchor_date").notNull().default(""),
  consecutiveLosses: integer("consecutive_losses").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const riskSettings = pgTable("risk_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  riskPerTradePct: doublePrecision("risk_per_trade_pct").notNull().default(0.5),
  maxDailyLossPct: doublePrecision("max_daily_loss_pct").notNull().default(2),
  maxDrawdownPct: doublePrecision("max_drawdown_pct").notNull().default(10),
  maxOpenPositions: integer("max_open_positions").notNull().default(3),
  maxExposurePct: doublePrecision("max_exposure_pct").notNull().default(30),
  maxPositionSizePct: doublePrecision("max_position_size_pct").notNull().default(15),
  maxConsecutiveLosses: integer("max_consecutive_losses").notNull().default(4),
  minRiskReward: doublePrecision("min_risk_reward").notNull().default(2),
  minScore: integer("min_score").notNull().default(65),
});

export const apiConnections = pgTable("api_connections", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  broker: text("broker").notNull(),
  environment: text("environment").notNull().default("SANDBOX"),
  label: text("label").notNull().default(""),
  apiKeyEnc: text("api_key_enc").notNull(),
  apiSecretEnc: text("api_secret_enc").notNull(),
  keyPreview: text("key_preview").notNull().default(""),
  withdrawalDisabled: boolean("withdrawal_disabled").notNull().default(true),
  active: boolean("active").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const signals = pgTable("signals", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(),
  entry: doublePrecision("entry").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  takeProfit: doublePrecision("take_profit").notNull(),
  riskReward: doublePrecision("risk_reward").notNull(),
  score: integer("score").notNull(),
  strategy: text("strategy").notNull(),
  reasons: jsonb("reasons").notNull().default([]),
  metrics: jsonb("metrics").notNull().default({}),
  status: text("status").notNull().default("NEW"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const positions = pgTable("positions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  signalId: integer("signal_id"),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(),
  mode: text("mode").notNull().default("PAPER"),
  entry: doublePrecision("entry").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  takeProfit: doublePrecision("take_profit").notNull(),
  size: doublePrecision("size").notNull(),
  notional: doublePrecision("notional").notNull(),
  riskAmount: doublePrecision("risk_amount").notNull(),
  strategy: text("strategy").notNull().default(""),
  score: integer("score").notNull().default(0),
  status: text("status").notNull().default("OPEN"),
  openedAt: timestamp("opened_at").notNull().defaultNow(),
});

export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  positionId: integer("position_id"),
  symbol: text("symbol").notNull(),
  direction: text("direction").notNull(),
  mode: text("mode").notNull().default("PAPER"),
  entry: doublePrecision("entry").notNull(),
  exit: doublePrecision("exit").notNull(),
  stopLoss: doublePrecision("stop_loss").notNull(),
  takeProfit: doublePrecision("take_profit").notNull(),
  size: doublePrecision("size").notNull(),
  riskAmount: doublePrecision("risk_amount").notNull(),
  pnl: doublePrecision("pnl").notNull(),
  pnlPct: doublePrecision("pnl_pct").notNull().default(0),
  strategy: text("strategy").notNull().default(""),
  score: integer("score").notNull().default(0),
  exitReason: text("exit_reason").notNull().default("MANUAL"),
  openedAt: timestamp("opened_at").notNull().defaultNow(),
  closedAt: timestamp("closed_at").notNull().defaultNow(),
});

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(),
  type: text("type").notNull().default("MARKET"),
  price: doublePrecision("price").notNull().default(0),
  size: doublePrecision("size").notNull().default(0),
  status: text("status").notNull().default("PENDING"),
  broker: text("broker").notNull().default("paper"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const backtests = pgTable("backtests", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  symbol: text("symbol").notNull(),
  strategy: text("strategy").notNull(),
  bars: integer("bars").notNull().default(500),
  result: jsonb("result").notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  level: text("level").notNull().default("info"),
  title: text("title").notNull(),
  body: text("body").notNull().default(""),
  readAt: timestamp("read_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  action: text("action").notNull(),
  detail: jsonb("detail").notNull().default({}),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
