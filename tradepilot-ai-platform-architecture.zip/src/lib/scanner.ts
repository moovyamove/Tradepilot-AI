import { ASSETS, Candle, getCandles, round } from "./market";
import { atr, ema, macd, rsi, sma, stdev, swingLevels } from "./indicators";

export type ScanMetrics = {
  price: number;
  trend: "UP" | "DOWN" | "RANGE";
  trendStrength: number;
  momentum: number;
  rsi: number;
  macdHist: number;
  atr: number;
  atrPct: number;
  volatility: number;
  volumeRatio: number;
  support: number;
  resistance: number;
  structure: string;
  breakout: boolean;
  pullback: boolean;
  ema20: number;
  ema50: number;
  sma200: number;
  change24h: number;
};

export type ScanResult = {
  symbol: string;
  name: string;
  kind: string;
  score: number;
  grade: string;
  direction: "BUY" | "SELL" | "NONE";
  strategy: string;
  reasons: string[];
  metrics: ScanMetrics;
};

export function grade(score: number): string {
  if (score >= 90) return "TRES FORTE";
  if (score >= 80) return "FORTE";
  if (score >= 65) return "INTERESSANTE";
  if (score >= 50) return "FAIBLE";
  return "AUCUNE";
}

export function analyze(symbol: string, candles?: Candle[]): ScanResult {
  const asset = ASSETS.find((a) => a.symbol === symbol)!;
  const c = candles ?? getCandles(symbol, 300);
  const closes = c.map((x) => x.c);
  const i = closes.length - 1;
  const e20 = ema(closes, 20);
  const e50 = ema(closes, 50);
  const s200 = sma(closes, 200);
  const r = rsi(closes, 14);
  const m = macd(closes);
  const a = atr(c, 14);
  const { support, resistance } = swingLevels(c, 60);
  const price = closes[i];
  const atrVal = a[i];
  const atrPct = (atrVal / price) * 100;
  const volAvg = c.slice(-40).reduce((s, x) => s + x.v, 0) / 40;
  const volumeRatio = c[i].v / (volAvg || 1);
  const slope = (e20[i] - e20[i - 10]) / (Math.abs(e20[i - 10]) || 1);
  const trendStrength = Math.min(100, Math.abs(slope) * 4000);
  const up = e20[i] > e50[i] && price > s200[i];
  const down = e20[i] < e50[i] && price < s200[i];
  const trend: ScanMetrics["trend"] = up ? "UP" : down ? "DOWN" : "RANGE";
  const momentum = ((price - closes[i - 10]) / closes[i - 10]) * 100;
  const volatility = (stdev(closes.slice(-40), 40) / price) * 100;
  const range = resistance - support || 1;
  const posInRange = (price - support) / range;
  const breakout = price > resistance * 0.998 || price < support * 1.002;
  const pullback =
    (trend === "UP" && price < e20[i] && price > e50[i]) ||
    (trend === "DOWN" && price > e20[i] && price < e50[i]);
  const structure =
    trend === "UP"
      ? "Higher highs / higher lows"
      : trend === "DOWN"
        ? "Lower highs / lower lows"
        : "Range / consolidation";

  const reasons: string[] = [];
  let score = 40;
  let direction: ScanResult["direction"] = "NONE";

  if (trend === "UP") {
    direction = "BUY";
    score += 12;
    reasons.push("Tendance haussière: EMA20 > EMA50 et prix au-dessus de la SMA200.");
  } else if (trend === "DOWN") {
    direction = "SELL";
    score += 12;
    reasons.push("Tendance baissière: EMA20 < EMA50 et prix sous la SMA200.");
  } else {
    reasons.push("Marché en range: structure non directionnelle, qualité du signal réduite.");
    direction = momentum >= 0 ? "BUY" : "SELL";
  }

  score += Math.min(12, trendStrength / 8);
  if (direction === "BUY" && m.hist[i] > 0) {
    score += 9;
    reasons.push("MACD positif: momentum acheteur confirmé.");
  }
  if (direction === "SELL" && m.hist[i] < 0) {
    score += 9;
    reasons.push("MACD négatif: momentum vendeur confirmé.");
  }
  if (direction === "BUY" && r[i] > 45 && r[i] < 72) {
    score += 8;
    reasons.push(`RSI ${r[i].toFixed(1)} dans une zone de continuation haussière.`);
  } else if (direction === "SELL" && r[i] < 55 && r[i] > 28) {
    score += 8;
    reasons.push(`RSI ${r[i].toFixed(1)} dans une zone de continuation baissière.`);
  } else {
    score -= 6;
    reasons.push(`RSI ${r[i].toFixed(1)} en zone extrême: risque de retournement.`);
  }
  if (volumeRatio > 1.2) {
    score += 7;
    reasons.push(`Volume ${volumeRatio.toFixed(2)}x la moyenne: participation confirmée.`);
  } else if (volumeRatio < 0.7) {
    score -= 5;
    reasons.push("Volume faible: manque de confirmation.");
  }
  if (breakout) {
    score += 8;
    reasons.push("Cassure d'un niveau clé (support/résistance sur 60 bougies).");
  }
  if (pullback) {
    score += 6;
    reasons.push("Pullback sur la moyenne mobile dans le sens de la tendance.");
  }
  if (atrPct > 6) {
    score -= 10;
    reasons.push(`Volatilité élevée (ATR ${atrPct.toFixed(2)}% du prix): risque accru.`);
  } else if (atrPct < 0.15) {
    score -= 6;
    reasons.push("Volatilité trop faible: potentiel de mouvement limité.");
  }
  if (direction === "BUY" && posInRange > 0.9 && !breakout) {
    score -= 6;
    reasons.push("Prix collé à la résistance sans cassure validée.");
  }
  if (direction === "SELL" && posInRange < 0.1 && !breakout) {
    score -= 6;
    reasons.push("Prix collé au support sans cassure validée.");
  }

  score = Math.max(0, Math.min(100, Math.round(score)));
  if (score < 50) direction = "NONE";

  const strategy =
    breakout && trend !== "RANGE"
      ? "Trend Breakout"
      : pullback
        ? "Trend Pullback"
        : trend === "RANGE"
          ? "Mean Reversion"
          : "Momentum Continuation";

  return {
    symbol,
    name: asset.name,
    kind: asset.kind,
    score,
    grade: grade(score),
    direction,
    strategy,
    reasons,
    metrics: {
      price: round(symbol, price),
      trend,
      trendStrength: Number(trendStrength.toFixed(1)),
      momentum: Number(momentum.toFixed(2)),
      rsi: Number(r[i].toFixed(1)),
      macdHist: Number(m.hist[i].toFixed(4)),
      atr: Number(atrVal.toFixed(6)),
      atrPct: Number(atrPct.toFixed(2)),
      volatility: Number(volatility.toFixed(2)),
      volumeRatio: Number(volumeRatio.toFixed(2)),
      support: round(symbol, support),
      resistance: round(symbol, resistance),
      structure,
      breakout,
      pullback,
      ema20: round(symbol, e20[i]),
      ema50: round(symbol, e50[i]),
      sma200: round(symbol, s200[i]),
      change24h: Number((((price - closes[i - 96]) / closes[i - 96]) * 100).toFixed(2)),
    },
  };
}

export function scanAll(): ScanResult[] {
  return ASSETS.map((a) => analyze(a.symbol)).sort((x, y) => y.score - x.score);
}
