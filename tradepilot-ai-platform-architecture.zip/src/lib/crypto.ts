import crypto from "crypto";

const secret = process.env.ENCRYPTION_KEY || process.env.AUTH_SECRET || "tradepilot-dev-secret-change-me";
const key = crypto.createHash("sha256").update(secret).digest();

/** AES-256-GCM encryption for broker API secrets. Never leaves the server. */
export function encryptSecret(plain: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `${iv.toString("base64")}.${tag.toString("base64")}.${enc.toString("base64")}`;
}

export function decryptSecret(payload: string): string {
  const [iv, tag, data] = payload.split(".");
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(iv, "base64"));
  decipher.setAuthTag(Buffer.from(tag, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(data, "base64")), decipher.final()]).toString("utf8");
}

export function maskKey(k: string): string {
  if (k.length <= 8) return "****";
  return `${k.slice(0, 4)}••••${k.slice(-4)}`;
}
