import { round } from "./market";
import type { ScanResult } from "./scanner";

export type Opportunity = {
  symbol: string;
  direction: "BUY" | "SELL";
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskReward: number;
  score: number;
  strategy: string;
  reasons: string[];
  metrics: ScanResult["metrics"];
};

/** Builds a tradable plan from a scan result. SL is always ATR/structure based. */
export function buildOpportunity(scan: ScanResult): Opportunity | null {
  if (scan.direction === "NONE") return null;
  const m = scan.metrics;
  const entry = m.price;
  const atrDist = Math.max(m.atr * 1.6, entry * 0.0025);
  let stopLoss: number;
  if (scan.direction === "BUY") {
    const structural = m.support - m.atr * 0.3;
    stopLoss = Math.min(entry - atrDist, structural > 0 ? Math.max(structural, entry * 0.9) : entry - atrDist);
  } else {
    const structural = m.resistance + m.atr * 0.3;
    stopLoss = Math.max(entry + atrDist, Math.min(structural, entry * 1.1));
  }
  const riskDist = Math.abs(entry - stopLoss);
  if (riskDist <= 0) return null;
  // Target is derived from structure, capped so RR stays realistic.
  const rrTarget = scan.score >= 85 ? 3 : scan.score >= 75 ? 2.5 : 2;
  const takeProfit =
    scan.direction === "BUY" ? entry + riskDist * rrTarget : entry - riskDist * rrTarget;
  const riskReward = Math.abs(takeProfit - entry) / riskDist;

  return {
    symbol: scan.symbol,
    direction: scan.direction,
    entry: round(scan.symbol, entry),
    stopLoss: round(scan.symbol, stopLoss),
    takeProfit: round(scan.symbol, takeProfit),
    riskReward: Number(riskReward.toFixed(2)),
    score: scan.score,
    strategy: scan.strategy,
    reasons: scan.reasons,
    metrics: m,
  };
}
