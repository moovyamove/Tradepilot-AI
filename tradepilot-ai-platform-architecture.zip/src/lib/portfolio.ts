import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { accounts, auditLogs, notifications, positions, riskSettings, trades } from "@/db/schema";
import { lastPrice } from "./market";
import { autoHaltReason, type AccountState, type RiskConfig } from "./risk";

export async function notify(userId: number, level: string, title: string, body = "") {
  await db.insert(notifications).values({ userId, level, title, body });
}

export async function audit(userId: number | null, action: string, detail: unknown = {}) {
  await db.insert(auditLogs).values({ userId, action, detail: detail as object });
}

export async function getRisk(userId: number): Promise<RiskConfig> {
  const [r] = await db.select().from(riskSettings).where(eq(riskSettings.userId, userId)).limit(1);
  if (!r) {
    await db.insert(riskSettings).values({ userId });
    return getRisk(userId);
  }
  const { id: _i, userId: _u, ...cfg } = r;
  void _i;
  void _u;
  return cfg as RiskConfig;
}

export async function getAccount(userId: number) {
  const [a] = await db.select().from(accounts).where(eq(accounts.userId, userId)).limit(1);
  if (!a) {
    await db.insert(accounts).values({ userId, dayAnchorDate: new Date().toISOString().slice(0, 10) });
    return getAccount(userId);
  }
  return a;
}

export type OpenPos = {
  id: number;
  symbol: string;
  direction: string;
  entry: number;
  stopLoss: number;
  takeProfit: number;
  size: number;
  notional: number;
  riskAmount: number;
  strategy: string;
  score: number;
  mode: string;
  openedAt: Date;
  price: number;
  pnl: number;
  pnlPct: number;
};

function pnlOf(direction: string, entry: number, price: number, size: number) {
  return (direction === "BUY" ? price - entry : entry - price) * size;
}

export async function closePosition(
  userId: number,
  posId: number,
  exitPrice: number,
  reason: string,
) {
  const [p] = await db
    .select()
    .from(positions)
    .where(and(eq(positions.id, posId), eq(positions.userId, userId)))
    .limit(1);
  if (!p || p.status !== "OPEN") return null;
  const pnl = pnlOf(p.direction, p.entry, exitPrice, p.size);
  await db.update(positions).set({ status: "CLOSED" }).where(eq(positions.id, posId));
  await db.insert(trades).values({
    userId,
    positionId: p.id,
    symbol: p.symbol,
    direction: p.direction,
    mode: p.mode,
    entry: p.entry,
    exit: exitPrice,
    stopLoss: p.stopLoss,
    takeProfit: p.takeProfit,
    size: p.size,
    riskAmount: p.riskAmount,
    pnl,
    pnlPct: (pnl / (p.notional || 1)) * 100,
    strategy: p.strategy,
    score: p.score,
    exitReason: reason,
    openedAt: p.openedAt,
    closedAt: new Date(),
  });
  const acc = await getAccount(userId);
  await db
    .update(accounts)
    .set({
      balance: acc.balance + pnl,
      consecutiveLosses: pnl < 0 ? acc.consecutiveLosses + 1 : 0,
    })
    .where(eq(accounts.id, acc.id));
  await notify(
    userId,
    pnl >= 0 ? "success" : "danger",
    `Position fermée ${p.symbol} (${reason})`,
    `P&L ${pnl >= 0 ? "+" : ""}${pnl.toFixed(2)} USD`,
  );
  await audit(userId, "POSITION_CLOSED", { posId, exitPrice, reason, pnl });
  return pnl;
}

/** Mark-to-market, auto SL/TP execution, daily anchor roll, auto-halt enforcement. */
export async function syncPortfolio(userId: number) {
  let acc = await getAccount(userId);
  const cfg = await getRisk(userId);
  const today = new Date().toISOString().slice(0, 10);

  let open = await db
    .select()
    .from(positions)
    .where(and(eq(positions.userId, userId), eq(positions.status, "OPEN")));

  // Resolve stop-loss / take-profit hits.
  for (const p of open) {
    const price = lastPrice(p.symbol);
    const hitSl = p.direction === "BUY" ? price <= p.stopLoss : price >= p.stopLoss;
    const hitTp = p.direction === "BUY" ? price >= p.takeProfit : price <= p.takeProfit;
    if (hitSl) await closePosition(userId, p.id, p.stopLoss, "STOP_LOSS");
    else if (hitTp) await closePosition(userId, p.id, p.takeProfit, "TAKE_PROFIT");
  }

  acc = await getAccount(userId);
  open = await db
    .select()
    .from(positions)
    .where(and(eq(positions.userId, userId), eq(positions.status, "OPEN")));

  const openPositions: OpenPos[] = open.map((p) => {
    const price = lastPrice(p.symbol);
    const pnl = pnlOf(p.direction, p.entry, price, p.size);
    return {
      id: p.id,
      symbol: p.symbol,
      direction: p.direction,
      entry: p.entry,
      stopLoss: p.stopLoss,
      takeProfit: p.takeProfit,
      size: p.size,
      notional: p.notional,
      riskAmount: p.riskAmount,
      strategy: p.strategy,
      score: p.score,
      mode: p.mode,
      openedAt: p.openedAt,
      price,
      pnl,
      pnlPct: (pnl / (p.notional || 1)) * 100,
    };
  });

  const unrealized = openPositions.reduce((s, p) => s + p.pnl, 0);
  const equity = acc.balance + unrealized;
  const exposure = openPositions.reduce((s, p) => s + p.size * p.price, 0);

  const patch: Partial<typeof accounts.$inferInsert> = {};
  if (equity > acc.equityPeak) patch.equityPeak = equity;
  if (acc.dayAnchorDate !== today) {
    patch.dayAnchorDate = today;
    patch.dayAnchorEquity = equity;
  }
  if (Object.keys(patch).length) {
    await db.update(accounts).set(patch).where(eq(accounts.id, acc.id));
    acc = await getAccount(userId);
  }

  const state: AccountState = {
    balance: acc.balance,
    equity,
    equityPeak: acc.equityPeak,
    dayAnchorEquity: acc.dayAnchorEquity,
    openPositions: openPositions.length,
    exposure,
    consecutiveLosses: acc.consecutiveLosses,
    killSwitch: acc.killSwitch,
    autoTrading: acc.autoTrading,
    mode: acc.mode as "PAPER" | "LIVE",
  };

  const halt = autoHaltReason(cfg, state);
  if (halt && !acc.killSwitch) {
    await db
      .update(accounts)
      .set({ killSwitch: true, autoTrading: false, killReason: halt })
      .where(eq(accounts.id, acc.id));
    await notify(userId, "danger", "Arrêt automatique du système", halt);
    await audit(userId, "AUTO_HALT", { reason: halt });
    state.killSwitch = true;
    state.autoTrading = false;
    acc = await getAccount(userId);
  }

  return { acc, cfg, state, openPositions };
}

export async function getStats(userId: number) {
  const { acc, cfg, state, openPositions } = await syncPortfolio(userId);
  const all = await db
    .select()
    .from(trades)
    .where(eq(trades.userId, userId))
    .orderBy(desc(trades.closedAt));
  const wins = all.filter((t) => t.pnl > 0);
  const losses = all.filter((t) => t.pnl <= 0);
  const realized = all.reduce((s, t) => s + t.pnl, 0);
  const today = new Date().toISOString().slice(0, 10);
  const dayPnl =
    all.filter((t) => t.closedAt.toISOString().slice(0, 10) === today).reduce((s, t) => s + t.pnl, 0) +
    openPositions.reduce((s, p) => s + p.pnl, 0);

  // Equity curve from starting balance.
  const curve: { t: string; equity: number; drawdown: number }[] = [];
  let equityRun = acc.startingBalance;
  let peak = equityRun;
  curve.push({ t: "start", equity: equityRun, drawdown: 0 });
  for (const t of [...all].reverse()) {
    equityRun += t.pnl;
    peak = Math.max(peak, equityRun);
    curve.push({
      t: t.closedAt.toISOString().slice(0, 16).replace("T", " "),
      equity: Number(equityRun.toFixed(2)),
      drawdown: Number((((peak - equityRun) / peak) * 100).toFixed(2)),
    });
  }
  curve.push({
    t: "now",
    equity: Number(state.equity.toFixed(2)),
    drawdown: Number((((Math.max(peak, state.equity) - state.equity) / Math.max(peak, state.equity)) * 100).toFixed(2)),
  });

  const grossWin = wins.reduce((s, t) => s + t.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + t.pnl, 0));

  return {
    account: {
      mode: acc.mode,
      autoTrading: acc.autoTrading,
      killSwitch: acc.killSwitch,
      killReason: acc.killReason,
      balance: Number(acc.balance.toFixed(2)),
      startingBalance: acc.startingBalance,
      consecutiveLosses: acc.consecutiveLosses,
    },
    risk: cfg,
    metrics: {
      equity: Number(state.equity.toFixed(2)),
      balance: Number(acc.balance.toFixed(2)),
      dayPnl: Number(dayPnl.toFixed(2)),
      totalPnl: Number((state.equity - acc.startingBalance).toFixed(2)),
      realizedPnl: Number(realized.toFixed(2)),
      drawdownPct: Number((((state.equityPeak - state.equity) / (state.equityPeak || 1)) * 100).toFixed(2)),
      maxDrawdownPct: Number(Math.max(0, ...curve.map((c) => c.drawdown)).toFixed(2)),
      winRate: all.length ? Number(((wins.length / all.length) * 100).toFixed(1)) : 0,
      trades: all.length,
      wins: wins.length,
      losses: losses.length,
      exposure: Number(state.exposure.toFixed(2)),
      exposurePct: Number(((state.exposure / (state.equity || 1)) * 100).toFixed(2)),
      riskInMarket: Number(openPositions.reduce((s, p) => s + p.riskAmount, 0).toFixed(2)),
      riskInMarketPct: Number(
        ((openPositions.reduce((s, p) => s + p.riskAmount, 0) / (state.equity || 1)) * 100).toFixed(2),
      ),
      profitFactor: grossLoss > 0 ? Number((grossWin / grossLoss).toFixed(2)) : grossWin > 0 ? 99 : 0,
      avgWin: wins.length ? Number((grossWin / wins.length).toFixed(2)) : 0,
      avgLoss: losses.length ? Number((grossLoss / losses.length).toFixed(2)) : 0,
      dailyLossUsedPct: Number(
        (((acc.dayAnchorEquity - state.equity) / (acc.dayAnchorEquity || 1)) * 100).toFixed(2),
      ),
    },
    openPositions,
    curve,
    recentTrades: all.slice(0, 20),
  };
}
