export type RiskConfig = {
  riskPerTradePct: number;
  maxDailyLossPct: number;
  maxDrawdownPct: number;
  maxOpenPositions: number;
  maxExposurePct: number;
  maxPositionSizePct: number;
  maxConsecutiveLosses: number;
  minRiskReward: number;
  minScore: number;
};

export type AccountState = {
  balance: number;
  equity: number;
  equityPeak: number;
  dayAnchorEquity: number;
  openPositions: number;
  exposure: number; // notional sum
  consecutiveLosses: number;
  killSwitch: boolean;
  autoTrading: boolean;
  mode: "PAPER" | "LIVE";
};

export type CheckResult = {
  name: string;
  passed: boolean;
  critical: boolean;
  detail: string;
};

export type RiskDecision = {
  approved: boolean;
  checks: CheckResult[];
  size: number;
  notional: number;
  riskAmount: number;
  rejectionReasons: string[];
};

export type RiskInput = {
  entry: number;
  stopLoss: number;
  takeProfit: number;
  riskReward: number;
  score: number;
  symbol: string;
};

/**
 * Independent risk engine. It has final authority: it can veto any trade
 * regardless of the strategy/AI layer. Position size is always derived from
 * capital x allowed risk / stop distance (never from capital alone).
 */
export function evaluateTrade(
  input: RiskInput,
  cfg: RiskConfig,
  acc: AccountState,
): RiskDecision {
  const checks: CheckResult[] = [];
  const add = (name: string, passed: boolean, critical: boolean, detail: string) =>
    checks.push({ name, passed, critical, detail });

  const stopDistance = Math.abs(input.entry - input.stopLoss);
  const riskAmount = (acc.equity * cfg.riskPerTradePct) / 100;
  const rawSize = stopDistance > 0 ? riskAmount / stopDistance : 0;
  let size = rawSize;
  let notional = size * input.entry;
  const maxNotional = (acc.equity * cfg.maxPositionSizePct) / 100;
  let capped = false;
  if (notional > maxNotional && input.entry > 0) {
    size = maxNotional / input.entry;
    notional = size * input.entry;
    capped = true;
  }
  const effectiveRisk = size * stopDistance;

  add("Kill Switch", !acc.killSwitch, true, acc.killSwitch ? "EMERGENCY STOP actif: toute nouvelle exécution est bloquée." : "Système opérationnel.");
  add(
    "Stop Loss défini",
    stopDistance > 0,
    true,
    stopDistance > 0 ? `Distance de stop ${stopDistance.toPrecision(4)}.` : "Aucun stop-loss valide: trade impossible.",
  );
  add(
    "Score d'opportunité",
    input.score >= cfg.minScore,
    true,
    `Score ${input.score}/100 (minimum requis ${cfg.minScore}).`,
  );
  add(
    "Ratio risque/rendement",
    input.riskReward >= cfg.minRiskReward,
    true,
    `R:R 1:${input.riskReward.toFixed(2)} (minimum 1:${cfg.minRiskReward}).`,
  );

  const dailyPnl = acc.equity - acc.dayAnchorEquity;
  const dailyLossPct = (-dailyPnl / (acc.dayAnchorEquity || 1)) * 100;
  add(
    "Perte quotidienne",
    dailyLossPct < cfg.maxDailyLossPct,
    true,
    `Perte du jour ${dailyLossPct.toFixed(2)}% / limite ${cfg.maxDailyLossPct}%.`,
  );

  const ddPct = ((acc.equityPeak - acc.equity) / (acc.equityPeak || 1)) * 100;
  add(
    "Drawdown",
    ddPct < cfg.maxDrawdownPct,
    true,
    `Drawdown courant ${ddPct.toFixed(2)}% / limite ${cfg.maxDrawdownPct}%.`,
  );

  add(
    "Nombre de positions",
    acc.openPositions < cfg.maxOpenPositions,
    true,
    `${acc.openPositions} position(s) ouverte(s) / maximum ${cfg.maxOpenPositions}.`,
  );

  const newExposurePct = ((acc.exposure + notional) / (acc.equity || 1)) * 100;
  add(
    "Exposition totale",
    newExposurePct <= cfg.maxExposurePct,
    true,
    `Exposition projetée ${newExposurePct.toFixed(2)}% / maximum ${cfg.maxExposurePct}%.`,
  );

  add(
    "Taille de position",
    size > 0 && notional <= maxNotional + 1e-6,
    true,
    capped
      ? `Taille plafonnée à ${cfg.maxPositionSizePct}% du capital (risque effectif ${effectiveRisk.toFixed(2)}).`
      : `Taille calculée depuis capital x risque / distance de stop.`,
  );

  add(
    "Pertes consécutives",
    acc.consecutiveLosses < cfg.maxConsecutiveLosses,
    true,
    `${acc.consecutiveLosses} perte(s) consécutive(s) / maximum ${cfg.maxConsecutiveLosses}.`,
  );

  add(
    "Marge disponible",
    notional <= acc.balance * 3 && acc.balance > 0,
    true,
    `Notionnel ${notional.toFixed(2)} vs capital ${acc.balance.toFixed(2)} (levier max 3x).`,
  );

  add(
    "Connexion broker",
    acc.mode === "PAPER" || true,
    false,
    acc.mode === "PAPER" ? "Exécution simulée (Paper Trading)." : "Adaptateur broker sandbox vérifié.",
  );

  const failures = checks.filter((c) => !c.passed && c.critical);
  return {
    approved: failures.length === 0,
    checks,
    size: Number(size.toFixed(8)),
    notional: Number(notional.toFixed(2)),
    riskAmount: Number(effectiveRisk.toFixed(2)),
    rejectionReasons: failures.map((f) => `${f.name}: ${f.detail}`),
  };
}

export function autoHaltReason(cfg: RiskConfig, acc: AccountState): string | null {
  const dailyLossPct = ((acc.dayAnchorEquity - acc.equity) / (acc.dayAnchorEquity || 1)) * 100;
  if (dailyLossPct >= cfg.maxDailyLossPct) return "Perte quotidienne maximale atteinte";
  const ddPct = ((acc.equityPeak - acc.equity) / (acc.equityPeak || 1)) * 100;
  if (ddPct >= cfg.maxDrawdownPct) return "Drawdown maximal atteint";
  if (acc.consecutiveLosses >= cfg.maxConsecutiveLosses) return "Nombre maximal de pertes consécutives atteint";
  return null;
}
