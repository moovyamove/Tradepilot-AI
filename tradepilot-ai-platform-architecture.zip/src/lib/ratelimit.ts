type Entry = { count: number; reset: number };
const store = new Map<string, Entry>();

/** Simple in-memory rate limiter (Redis-compatible interface shape). */
export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const e = store.get(key);
  if (!e || e.reset < now) {
    store.set(key, { count: 1, reset: now + windowMs });
    return true;
  }
  e.count += 1;
  return e.count <= limit;
}
