import { getCandles } from "./market";
import { analyze } from "./scanner";
import { buildOpportunity } from "./opportunity";
import type { RiskConfig } from "./risk";

export type BacktestResult = {
  symbol: string;
  strategy: string;
  bars: number;
  startingBalance: number;
  endingBalance: number;
  returnPct: number;
  trades: number;
  wins: number;
  losses: number;
  winRate: number;
  profitFactor: number;
  avgWin: number;
  avgLoss: number;
  expectancy: number;
  maxDrawdownPct: number;
  sharpe: number;
  equityCurve: { i: number; equity: number }[];
  tradeList: {
    i: number;
    direction: string;
    entry: number;
    exit: number;
    pnl: number;
    reason: string;
    score: number;
  }[];
  disclaimer: string;
};

export function runBacktest(
  symbol: string,
  bars: number,
  cfg: RiskConfig,
  startingBalance = 10000,
  strategyFilter = "ALL",
): BacktestResult {
  const total = bars + 300;
  const candles = getCandles(symbol, total);
  let balance = startingBalance;
  let peak = balance;
  let maxDd = 0;
  const equityCurve: BacktestResult["equityCurve"] = [];
  const tradeList: BacktestResult["tradeList"] = [];
  const returns: number[] = [];
  let open: {
    i: number;
    dir: "BUY" | "SELL";
    entry: number;
    sl: number;
    tp: number;
    size: number;
    score: number;
  } | null = null;
  let usedStrategy = strategyFilter;

  for (let i = 300; i < total; i++) {
    const slice = candles.slice(0, i + 1);
    const bar = candles[i];
    if (open) {
      const hitSl = open.dir === "BUY" ? bar.l <= open.sl : bar.h >= open.sl;
      const hitTp = open.dir === "BUY" ? bar.h >= open.tp : bar.l <= open.tp;
      if (hitSl || hitTp) {
        const exit = hitSl ? open.sl : open.tp;
        const pnl = (open.dir === "BUY" ? exit - open.entry : open.entry - exit) * open.size;
        balance += pnl;
        returns.push(pnl / startingBalance);
        tradeList.push({
          i,
          direction: open.dir,
          entry: open.entry,
          exit,
          pnl: Number(pnl.toFixed(2)),
          reason: hitSl ? "STOP_LOSS" : "TAKE_PROFIT",
          score: open.score,
        });
        open = null;
      }
    }
    if (!open && i % 4 === 0) {
      const scan = analyze(symbol, slice);
      if (scan.score >= cfg.minScore && (strategyFilter === "ALL" || scan.strategy === strategyFilter)) {
        const opp = buildOpportunity(scan);
        if (opp && opp.riskReward >= cfg.minRiskReward) {
          const riskAmount = (balance * cfg.riskPerTradePct) / 100;
          const dist = Math.abs(opp.entry - opp.stopLoss);
          let size = dist > 0 ? riskAmount / dist : 0;
          const maxNotional = (balance * cfg.maxPositionSizePct) / 100;
          if (size * opp.entry > maxNotional) size = maxNotional / opp.entry;
          if (size > 0) {
            usedStrategy = strategyFilter === "ALL" ? scan.strategy : strategyFilter;
            open = {
              i,
              dir: opp.direction,
              entry: opp.entry,
              sl: opp.stopLoss,
              tp: opp.takeProfit,
              size,
              score: opp.score,
            };
          }
        }
      }
    }
    peak = Math.max(peak, balance);
    maxDd = Math.max(maxDd, ((peak - balance) / peak) * 100);
    if (i % 5 === 0) equityCurve.push({ i: i - 300, equity: Number(balance.toFixed(2)) });
  }

  const wins = tradeList.filter((t) => t.pnl > 0);
  const losses = tradeList.filter((t) => t.pnl <= 0);
  const grossWin = wins.reduce((s, t) => s + t.pnl, 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + t.pnl, 0));
  const avgWin = wins.length ? grossWin / wins.length : 0;
  const avgLoss = losses.length ? grossLoss / losses.length : 0;
  const winRate = tradeList.length ? wins.length / tradeList.length : 0;
  const mean = returns.length ? returns.reduce((a, b) => a + b, 0) / returns.length : 0;
  const sd = returns.length
    ? Math.sqrt(returns.reduce((a, b) => a + (b - mean) ** 2, 0) / returns.length)
    : 0;

  return {
    symbol,
    strategy: usedStrategy,
    bars,
    startingBalance,
    endingBalance: Number(balance.toFixed(2)),
    returnPct: Number((((balance - startingBalance) / startingBalance) * 100).toFixed(2)),
    trades: tradeList.length,
    wins: wins.length,
    losses: losses.length,
    winRate: Number((winRate * 100).toFixed(1)),
    profitFactor: grossLoss > 0 ? Number((grossWin / grossLoss).toFixed(2)) : grossWin > 0 ? 99 : 0,
    avgWin: Number(avgWin.toFixed(2)),
    avgLoss: Number(avgLoss.toFixed(2)),
    expectancy: Number((winRate * avgWin - (1 - winRate) * avgLoss).toFixed(2)),
    maxDrawdownPct: Number(maxDd.toFixed(2)),
    sharpe: sd > 0 ? Number(((mean / sd) * Math.sqrt(returns.length || 1)).toFixed(2)) : 0,
    equityCurve,
    tradeList: tradeList.slice(-50).reverse(),
    disclaimer:
      "Les résultats historiques sont simulés et ne constituent en aucun cas une garantie de performance future.",
  };
}
