import { eq } from "drizzle-orm";
import { db } from "@/db";
import { notifications, trades } from "@/db/schema";
import { ASSETS, lastPrice } from "./market";

/** Seeds a demo history of paper trades so the dashboard is meaningful. */
export async function seedDemoData(userId: number) {
  const existing = await db.select().from(trades).where(eq(trades.userId, userId)).limit(1);
  if (existing.length) return;
  const rows: (typeof trades.$inferInsert)[] = [];
  const now = Date.now();
  for (let i = 0; i < 28; i++) {
    const a = ASSETS[i % ASSETS.length];
    const price = lastPrice(a.symbol);
    const direction = i % 3 === 0 ? "SELL" : "BUY";
    const entry = price * (1 + (((i * 37) % 11) - 5) / 400);
    const risk = 50;
    const dist = entry * 0.012;
    const size = risk / dist;
    const win = i % 10 !== 2 && i % 7 !== 3;
    const rr = 2 + (i % 3) * 0.5;
    const exit = direction === "BUY" ? (win ? entry + dist * rr : entry - dist) : win ? entry - dist * rr : entry + dist;
    const pnl = (direction === "BUY" ? exit - entry : entry - exit) * size;
    const openedAt = new Date(now - (28 - i) * 7 * 3600_000);
    rows.push({
      userId,
      symbol: a.symbol,
      direction,
      mode: "PAPER",
      entry,
      exit,
      stopLoss: direction === "BUY" ? entry - dist : entry + dist,
      takeProfit: direction === "BUY" ? entry + dist * rr : entry - dist * rr,
      size,
      riskAmount: risk,
      pnl,
      pnlPct: (pnl / (size * entry)) * 100,
      strategy: ["Trend Breakout", "Trend Pullback", "Momentum Continuation"][i % 3],
      score: 66 + (i % 30),
      exitReason: win ? "TAKE_PROFIT" : "STOP_LOSS",
      openedAt,
      closedAt: new Date(openedAt.getTime() + 4 * 3600_000),
    });
  }
  await db.insert(trades).values(rows);
  const net = rows.reduce((s, r) => s + (r.pnl as number), 0);
  await db
    .update((await import("@/db/schema")).accounts)
    .set({ balance: 10000 + net, equityPeak: 10000 + Math.max(net, 0) })
    .where(eq((await import("@/db/schema")).accounts.userId, userId));
  await db.insert(notifications).values({
    userId,
    level: "info",
    title: "Historique de démonstration chargé",
    body: "28 trades papier simulés. Aucune performance passée ne garantit les résultats futurs.",
  });
}
