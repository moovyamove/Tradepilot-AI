import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { accounts, riskSettings, users } from "@/db/schema";

const secret = new TextEncoder().encode(
  process.env.AUTH_SECRET || "tradepilot-dev-secret-change-me-please-32chars",
);
const COOKIE = "tp_session";

export async function createSession(userId: number) {
  const token = await new SignJWT({ uid: userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret);
  const store = await cookies();
  store.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function destroySession() {
  const store = await cookies();
  store.delete(COOKIE);
}

export async function getUserId(): Promise<number | null> {
  const store = await cookies();
  const token = store.get(COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    return typeof payload.uid === "number" ? payload.uid : null;
  } catch {
    return null;
  }
}

export async function requireUser() {
  const uid = await getUserId();
  if (!uid) return null;
  const [u] = await db.select().from(users).where(eq(users.id, uid)).limit(1);
  return u ?? null;
}

export async function ensureUserEnvironment(userId: number) {
  const [acc] = await db.select().from(accounts).where(eq(accounts.userId, userId)).limit(1);
  if (!acc) {
    const today = new Date().toISOString().slice(0, 10);
    await db.insert(accounts).values({ userId, dayAnchorDate: today });
  }
  const [rs] = await db.select().from(riskSettings).where(eq(riskSettings.userId, userId)).limit(1);
  if (!rs) await db.insert(riskSettings).values({ userId });
}
