import { lastPrice } from "../market";

export type BrokerOrder = {
  symbol: string;
  side: "BUY" | "SELL";
  type: "MARKET" | "LIMIT";
  size: number;
  price?: number;
};

export type BrokerOrderResult = {
  orderId: string;
  status: "FILLED" | "PENDING" | "REJECTED";
  filledPrice: number;
  message: string;
};

export interface TradingAdapter {
  id: string;
  name: string;
  kind: "broker" | "exchange";
  environments: string[];
  /** Withdrawal scope must never be requested. */
  requiredPermissions: string[];
  getBalance(): Promise<{ currency: string; available: number }>;
  getPositions(): Promise<unknown[]>;
  getPrice(symbol: string): Promise<number>;
  createOrder(o: BrokerOrder): Promise<BrokerOrderResult>;
  modifyOrder(id: string, changes: Partial<BrokerOrder>): Promise<BrokerOrderResult>;
  cancelOrder(id: string): Promise<{ ok: boolean }>;
  closePosition(symbol: string): Promise<{ ok: boolean; price: number }>;
  healthCheck(): Promise<{ ok: boolean; latencyMs: number; detail: string }>;
}

class PaperAdapter implements TradingAdapter {
  id = "paper";
  name = "TradePilot Paper Engine";
  kind: "broker" = "broker";
  environments = ["PAPER"];
  requiredPermissions = ["read", "trade"];
  constructor(private balance = 10000) {}
  async getBalance() {
    return { currency: "USDT", available: this.balance };
  }
  async getPositions() {
    return [];
  }
  async getPrice(symbol: string) {
    return lastPrice(symbol);
  }
  async createOrder(o: BrokerOrder): Promise<BrokerOrderResult> {
    const price = o.price ?? lastPrice(o.symbol);
    return { orderId: `paper-${Date.now()}`, status: "FILLED", filledPrice: price, message: "Ordre simulé exécuté" };
  }
  async modifyOrder(id: string, changes: Partial<BrokerOrder>): Promise<BrokerOrderResult> {
    return {
      orderId: id,
      status: "PENDING",
      filledPrice: changes.price ?? 0,
      message: "Ordre simulé modifié",
    };
  }
  async cancelOrder() {
    return { ok: true };
  }
  async closePosition(symbol: string) {
    return { ok: true, price: lastPrice(symbol) };
  }
  async healthCheck() {
    return { ok: true, latencyMs: 2, detail: "Moteur papier local" };
  }
}

class SandboxExchangeAdapter extends PaperAdapter {
  override id = "binance-testnet";
  override name = "Binance Spot Testnet";
  override kind: "broker" = "broker";
  override environments = ["SANDBOX"];
  override requiredPermissions = ["read", "spot-trade"];
  override async healthCheck() {
    return { ok: true, latencyMs: 48, detail: "Endpoint testnet simulé (aucune clé réelle requise)" };
  }
}

const registry: Record<string, TradingAdapter> = {
  paper: new PaperAdapter(),
  "binance-testnet": new SandboxExchangeAdapter(),
};

export function getAdapter(id: string): TradingAdapter {
  return registry[id] ?? registry.paper;
}

export function listAdapters() {
  return Object.values(registry).map((a) => ({
    id: a.id,
    name: a.name,
    kind: a.kind,
    environments: a.environments,
    requiredPermissions: a.requiredPermissions,
  }));
}
