export type Candle = { t: number; o: number; h: number; l: number; c: number; v: number };

export type AssetDef = { symbol: string; name: string; base: number; vol: number; kind: string };

export const ASSETS: AssetDef[] = [
  { symbol: "BTC/USDT", name: "Bitcoin", base: 64000, vol: 0.018, kind: "crypto" },
  { symbol: "ETH/USDT", name: "Ethereum", base: 3200, vol: 0.022, kind: "crypto" },
  { symbol: "SOL/USDT", name: "Solana", base: 145, vol: 0.032, kind: "crypto" },
  { symbol: "XRP/USDT", name: "Ripple", base: 0.58, vol: 0.028, kind: "crypto" },
  { symbol: "EUR/USD", name: "Euro / Dollar", base: 1.084, vol: 0.004, kind: "forex" },
  { symbol: "GBP/USD", name: "Pound / Dollar", base: 1.268, vol: 0.005, kind: "forex" },
  { symbol: "XAU/USD", name: "Gold", base: 2320, vol: 0.007, kind: "commodity" },
  { symbol: "AAPL", name: "Apple Inc.", base: 212, vol: 0.012, kind: "equity" },
  { symbol: "NVDA", name: "NVIDIA Corp.", base: 118, vol: 0.025, kind: "equity" },
  { symbol: "TSLA", name: "Tesla Inc.", base: 182, vol: 0.028, kind: "equity" },
];

export function getAsset(symbol: string): AssetDef | undefined {
  return ASSETS.find((a) => a.symbol === symbol);
}

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const BAR_MS = 15 * 60 * 1000;

/** Deterministic synthetic OHLC series (paper/sandbox market data feed). */
export function getCandles(symbol: string, bars = 300, endTime = Date.now()): Candle[] {
  const asset = getAsset(symbol) ?? ASSETS[0];
  const endBar = Math.floor(endTime / BAR_MS);
  const startBar = endBar - bars + 1;
  const rnd = mulberry32(hash(symbol));
  // Long deterministic walk anchored on absolute bar index.
  let price = asset.base;
  const out: Candle[] = [];
  const warmup = 200;
  for (let i = startBar - warmup; i <= endBar; i++) {
    const r = mulberry32(hash(symbol + ":" + i));
    const cycle =
      Math.sin(i / 90) * asset.vol * 0.9 + Math.sin(i / 23 + hash(symbol) % 7) * asset.vol * 0.5;
    const shock = (r() - 0.5) * asset.vol * 2;
    const drift = cycle * 0.35 + shock;
    const o = price;
    const c = Math.max(asset.base * 0.25, o * (1 + drift));
    const wick = Math.abs(drift) * o * (0.4 + r() * 0.8) + o * asset.vol * 0.12;
    const h = Math.max(o, c) + wick * r();
    const l = Math.min(o, c) - wick * r();
    const v = 1000 * (0.6 + r() * 1.6) * (1 + Math.abs(drift) * 25);
    price = c;
    if (i >= startBar) out.push({ t: i * BAR_MS, o, h, l, c, v: Math.round(v) });
  }
  void rnd;
  return out;
}

export function lastPrice(symbol: string): number {
  const c = getCandles(symbol, 3);
  return c[c.length - 1].c;
}

export function priceDecimals(symbol: string): number {
  const p = lastPrice(symbol);
  if (p > 1000) return 2;
  if (p > 10) return 2;
  if (p > 1) return 4;
  return 5;
}

export function round(symbol: string, v: number): number {
  const d = priceDecimals(symbol);
  return Number(v.toFixed(d));
}
